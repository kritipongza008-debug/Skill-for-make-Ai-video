---
name: clip-studio-3d
description: "Make 30-90 s vertical short clips (TikTok/Reels/Shorts) in one fixed 3D-look paper-cut style (layered depth, parallax, shadows, camera moves), delivered as a single HTML page with a Save-MP4 button. Flow: user gives a story OR asks Claude to invent one -> Claude returns the best TTS-ready script (one narrator, or split by voice/character on request) + ElevenLabs link -> user generates the voice -> Claude builds captions, camera, SFX, ducked music, loop ending, self-checks, publishes. Always web-searches any factual content. The phrase 'ต้องตรวจให้ละเอียดก่อนส่ง' triggers a deep check-and-improve pass. Use for: ทำคลิป, คลิปสั้น, วิดีโอสั้น, ทำคลิป 3D, คิดเนื้อเรื่อง/ไอเดียคลิป, เขียนบทพูด, บทพูดแยกเสียง/หลายตัวละคร, ทำเสียง ElevenLabs, ถ้าเกิดเป็น…, ใส่ซับ/เอฟเฟกต์/เพลงให้เสียงที่อัดมา, ตรวจ/แก้คลิป, ต้องตรวจให้ละเอียดก่อนส่ง. Not for long video, live-action editing, or generating the voice itself."
---

# Clip Studio 3D

Reply in the user's language (Thai: plain spoken, short sentences). Never paste code into chat; deliver links and files. Read only the reference named for the current mode (keeps tokens low).

## Mode
| User does | Do |
|---|---|
| Sends a story, or asks to invent one | **STORY** -> `references/story.md` (+ `references/voices.md` for the voice hand-off) |
| Uploads voice mp3 (one file, or several turn files) | **BUILD** -> `references/build.md` |
| Types **ต้องตรวจให้ละเอียดก่อนส่ง** (or asks to review/improve a clip) | **DEEP CHECK** -> `references/deep-check.md` |
| Wants a change to a finished clip | edit project files, rebuild, `Artifact edit` with the same `url`, standard check |
| Asks how it works | 5-line summary of `README.md` |

## Config (read from the user's message; ask at most ONE question, only if it blocks the work)
- **Voices**: default = one narrator. If the user says แยกเสียง / หลายตัวละคร / บทสนทนา: split mode (tags `[A] [B]…`, cast table, per-voice script). If the story is dialogue-heavy and the user did not say, deliver one narrator and offer split in one closing line.
- **Length**: default 45-75 s (~800 Thai chars/60 s). Kids: 30-45 s, nothing scary.
- **Look**: always the same detailed 3D-look paper-cut style as the approved clip. Build with `lib/rig.js` (`references/rig.md`): `ppl()` characters, `ROOM.*`/`floor()`+props sets. Never flat shapes or stick figures. Do not offer other styles.

## Hard rules
1. **Research is mandatory, every time.** If the story touches any real-world fact (date, number, history, science, place, product, "first/only/most") or the user says to look something up: run `web_search` BEFORE writing, even if you think you know it. At least one search per fact cluster. No search tool -> say so and mark the facts unverified. Contested topics: each side evenly, hedged ("เล่ากันว่า"). Keep a source list for the hand-off.
2. **ElevenLabs first, always**, with the link (details `references/voices.md`). Mention other TTS only after it. For ElevenLabs specifics beyond that file (features, prices, limits) search again, do not recall.
3. Return the **best version of the story**, not a menu: given story -> improve it; asked to invent -> write the single best one (at most 2 one-line alternates).
4. No real named people as comic/fictional characters (offer an invented look-alike); no lyrics/copyrighted text; no invented quotes.
5. Never claim you heard, watched or tested what you did not (audio, word sync, emoji, MP4 export in a real browser). Say it plainly at delivery.
6. Smooth by design: hard-offset shadows (no `shadowBlur`), no grain, 30 fps draw; check with `scripts/frame_cost.js`.

## Delivery (every build)
Link; what tools verified (numbers); what was NOT verified; one line "บอกเลขวินาทีที่ไม่ตรง แล้วผมแก้ให้".
