// Reference scenes: the "ถ้าเกิดเป็นเด็กช่าง" clip (user-approved quality bar). Read ONE scene at most; do not paste it.
/* ถ้าเกิดเป็นเด็กช่าง — all events tied to CD(k) */
/* centre text by measuring (textAlign:'center' drew left-aligned in the user's browser; captions use this approach and were fine) */
function tx(s,x,y,sz,c,o={}){g.font=(o.w||500)+' '+Math.max(1,sz)+'px '+F;g.textBaseline='middle';g.lineJoin='round';g.textAlign='left';const w=g.measureText(s).width,al=o.a||'center',xx=al==='center'?x-w/2:al==='right'?x-w:x;if(o.s){g.lineWidth=o.sw||12;g.strokeStyle=o.s;g.strokeText(s,xx,y)}g.fillStyle=c;g.fillText(s,xx,y)}
const SKIN='#f2c9a0',BT=Math.PI*2*141/60,PLD={red:['#d4382c','#7a1414','#ff9a80'],bw:['#d8d8dc','#26262b','#ffffff'],pink:['#e86a9a','#8f2150','#ffc6dc']};
const PAT={};function pat(pl){if(PAT[pl[0]])return PAT[pl[0]];const c=document.createElement('canvas');c.width=c.height=30;const x=c.getContext('2d');x.fillStyle=pl[0];x.fillRect(0,0,30,30);x.globalAlpha=.55;x.fillStyle=pl[1];x.fillRect(6,0,13,30);x.fillRect(0,6,30,13);x.globalAlpha=.6;x.fillStyle=pl[2];x.fillRect(22,0,2,30);x.fillRect(0,22,30,2);return PAT[pl[0]]=g.createPattern(c,'repeat')}
function hatShape(c){c=c||['#eef1f5','#d63b3b'];const sh=g.createRadialGradient(-22,-24,8,0,14,96);sh.addColorStop(0,'#ffffff');sh.addColorStop(.55,c[0]);sh.addColorStop(1,'#8d97a8');pap(()=>g.roundRect(-64,-54,128,134,58),sh,.8);pap(()=>g.roundRect(-30,-60,60,14,7),c[1],.1);const vq=g.createLinearGradient(0,2,0,46);vq.addColorStop(0,'#2a3446');vq.addColorStop(.5,'#0c1018');vq.addColorStop(1,'#1b2230');pap(()=>g.roundRect(-52,2,104,44,22),vq,.3);g.save();g.strokeStyle='rgba(255,255,255,.55)';g.lineWidth=5;g.lineCap='round';g.beginPath();g.moveTo(-38,14);g.lineTo(22,14);g.stroke();g.lineWidth=3;g.beginPath();g.moveTo(32,10);g.lineTo(42,32);g.stroke();g.strokeStyle='rgba(60,70,90,.7)';[58,66].forEach(y=>{g.beginPath();g.moveTo(-16,y);g.lineTo(16,y);g.stroke()});g.restore()}
function armDraw(sx,sy,ex,ey,tx0,ty0,col,sk,k,o){const dx=tx0-ex,dy=ty0-ey,L=Math.hypot(dx,dy)||1,ux=dx/L,uy=dy/L,R=Math.min(L,o.reach||88),wx=ex+ux*Math.max(R-22,10),wy=ey+uy*Math.max(R-22,10),hx=ex+ux*R,hy=ey+uy*R;
 g.save();g.lineCap='round';g.lineJoin='round';g.strokeStyle=col;g.fillStyle=col;g.lineWidth=30;g.beginPath();g.moveTo(sx,sy);g.lineTo(ex,ey);g.stroke();g.lineWidth=26;g.beginPath();g.moveTo(ex,ey);g.lineTo(wx,wy);g.stroke();g.beginPath();g.arc(ex,ey,14,0,7);g.fill();
 g.strokeStyle='rgba(0,0,0,.25)';g.lineWidth=26;g.beginPath();g.moveTo(wx-ux*7,wy-uy*7);g.lineTo(wx,wy);g.stroke();
 if(o.wr){g.save();g.translate(hx,hy);g.rotate(.4+Math.sin(o.t*BT)*.12);g.scale(.85,.85);pap(()=>g.roundRect(-9,-40,18,150,7),'#b9c2cc',.5);pap(()=>{g.moveTo(-9,-42);g.lineTo(-27,-64);g.lineTo(-21,-102);g.lineTo(-9,-106);g.lineTo(-9,-82);g.lineTo(0,-74);g.lineTo(9,-82);g.lineTo(9,-106);g.lineTo(21,-102);g.lineTo(27,-64);g.lineTo(9,-42)},'#d5dce3',.5);g.restore()}
 if(!o.hide){g.save();g.translate(hx,hy);g.rotate(Math.atan2(uy,ux)-Math.PI/2);g.fillStyle=sk;g.beginPath();g.ellipse(0,0,12,17,0,0,7);g.fill();g.fillStyle='rgba(0,0,0,.15)';g.beginPath();g.ellipse(k*6,-7,5,9,0,0,7);g.fill();g.restore()}
 g.restore()}
function ppl(x,y,s,o={}){const t=o.t||0,d=o.dance||0,w=o.walk?1:0,ph=t*BT,sw=Math.sin(t*BT*.5)*d,bob=Math.abs(Math.sin(t*BT))*8*d+Math.abs(Math.sin(ph))*4*w,sk=o.skin||SKIN,pl=o.plaid||(o.shirt==='#4a3330'?PLD.red:null),bs=pl?pl[0]:(o.shirt||'#6c7a89'),fill=pl?pat(pl):bs,K=.86,bn=Math.sin(t*BT)*12;
 g.save();if(!o.noshadow)groundShadow(x,y+4,100*s*K,.3);g.translate(x+sw*18*s*K,y);g.scale(s*K*(o.flip?-1:1),s*K);
 const jq=g.createLinearGradient(-40,0,40,0);jq.addColorStop(0,'#2c3b5e');jq.addColorStop(.5,'#4a6190');jq.addColorStop(1,'#2c3b5e');const jc=o.pants||jq;
 const bb=d?(.5+.5*Math.sin(t*BT-1.2)):0,th0=.45*bb,ps0=.5*bb,drop=d&&!w?236-118*(Math.cos(th0)+Math.cos(ps0)):0,hipY=-238+drop-Math.abs(Math.sin(ph))*4*w;
 [-1,1].forEach(k=>{g.save();g.translate(k*24,hipY);g.rotate(w?Math.sin(ph/2+k*1.57)*.45:k*th0);
  pap(()=>{g.moveTo(-24,0);g.lineTo(24,0);g.lineTo(27,120);g.lineTo(-27,120)},jc,.4);
  g.save();g.strokeStyle='rgba(15,25,50,.45)';g.lineWidth=3;g.lineCap='round';g.beginPath();g.moveTo(-18,100);g.quadraticCurveTo(0,107,18,100);g.stroke();g.restore();
  g.translate(0,118);g.rotate(w?0:-k*.95*bb);
  pap(()=>{g.moveTo(-26,-2);g.lineTo(26,-2);g.quadraticCurveTo(28,58,42,118);g.lineTo(-42,118);g.quadraticCurveTo(-28,58,-26,-2)},jc,.4);
  g.fillStyle=jc;g.beginPath();g.arc(0,0,25,0,7);g.fill();
  g.save();g.strokeStyle='rgba(15,25,50,.45)';g.lineWidth=3;g.lineCap='round';[88,100].forEach(yy=>{g.beginPath();g.moveTo(-28,yy);g.quadraticCurveTo(0,yy+7,28,yy);g.stroke()});g.restore();
  pap(()=>g.ellipse(6,122,40,13,0,0,7),'#2b2b30',.4);g.fillStyle='#e9e9ee';g.beginPath();g.ellipse(6,130,40,5,0,0,7);g.fill();g.restore()});
 g.translate(0,hipY);g.rotate(sw*.09);
 pap(()=>g.roundRect(-47,-16,94,34,10),jc,.3);
 pap(()=>g.roundRect(-10,-174,20,30,6),sk,.3);
 const tp=()=>{g.moveTo(-46,4);g.lineTo(46,4);g.lineTo(58,-128);g.quadraticCurveTo(62,-150,40,-154);g.lineTo(-40,-154);g.quadraticCurveTo(-62,-150,-58,-128);g.closePath()};
 pap(tp,fill,1);
 g.save();g.beginPath();tp();g.clip();const q=g.createLinearGradient(-58,0,58,0);q.addColorStop(0,'rgba(0,0,0,.35)');q.addColorStop(.3,'rgba(255,255,255,.08)');q.addColorStop(.7,'rgba(0,0,0,.05)');q.addColorStop(1,'rgba(0,0,0,.4)');g.fillStyle=q;g.fillRect(-60,-156,120,162);const q2=g.createLinearGradient(0,-154,0,4);q2.addColorStop(0,'rgba(255,255,255,.1)');q2.addColorStop(1,'rgba(0,0,0,.25)');g.fillStyle=q2;g.fillRect(-60,-156,120,162);
 g.fillStyle='#2b2220';g.fillRect(-48,-8,96,14);g.fillStyle='#d9b45a';g.fillRect(-12,-10,24,18);g.fillStyle='#8a6a2a';g.fillRect(-6,-6,12,10);
 if(pl){g.strokeStyle='rgba(0,0,0,.4)';g.lineWidth=2.5;g.beginPath();g.moveTo(0,-132);g.lineTo(0,-10);g.stroke();[-1,1].forEach(k=>g.strokeRect(k*24-12,-112,24,28));g.fillStyle='#fff';[-100,-62,-30].forEach(yy=>{g.beginPath();g.arc(0,yy,3.6,0,7);g.fill()})}
 if(o.apron)pap(()=>g.roundRect(-34,-118,68,122,16),'#fff3d0',.5);
 g.restore();
 pap(()=>{g.moveTo(-14,-156);g.lineTo(14,-156);g.lineTo(0,-130)},sk,0);[-1,1].forEach(k=>pap(()=>{g.moveTo(k*28,-158);g.lineTo(k*4,-152);g.lineTo(k*2,-128);g.lineTo(k*24,-142)},fill,.2));
 [-1,1].forEach(k=>pap(()=>g.arc(k*55,-138,17,0,7),fill,.5));
 if(o.pocket){[-1,1].forEach(k=>{if(o.hold&&k===-1){armDraw(-54,-142,-80,-72,-72,14,fill,sk,-1,{t});g.save();g.translate(-72,62+Math.sin(t*3)*3);g.rotate(Math.sin(t*BT)*.12);const hk=o.holdK==null?1:o.holdK;g.scale(.55*hk,.55*hk);hatShape();g.restore()}else armDraw(k*54,-142,k*68,-72,k*40,-6,fill,sk,k,{t,hide:1})})}
 else if(o.tool){armDraw(-54,-142,-92,-118,-30,-158,fill,sk,-1,{t,hide:1,reach:110});if(o.bowl){armDraw(54,-142,84,-80,52,-112,fill,sk,1,{t});g.save();g.translate(52,-100);pap(()=>{g.moveTo(-32,-10);g.lineTo(32,-10);g.quadraticCurveTo(28,26,0,28);g.quadraticCurveTo(-28,26,-32,-10)},'#fff',.5);pap(()=>g.arc(0,-10,30,Math.PI,0),'#fffdf5',.3);g.restore()}else armDraw(54,-142,100,-205,122,-285+bn,fill,sk,1,{t})}
 else if(o.wrench){armDraw(54,-142,100,-72,120,-122,fill,sk,1,{t,wr:1});armDraw(-54,-142,-100,-205,-122,-285+bn,fill,sk,-1,{t})}
 else{[-1,1].forEach(k=>armDraw(k*54,-142,k*(94+12*bb),-205+bn*.5,k*10,-255+bn*.5-bb*8,fill,sk,k,{t}))}
 g.translate(0,-160);g.rotate(o.tilt||0);g.translate(0,-34);
 if(o.hat){g.save();g.translate(0,-9.6);g.scale(.74,.74);hatShape(o.hel);g.restore()}
 else{const fg=g.createRadialGradient(-8,-10,4,0,0,42);fg.addColorStop(0,'#ffe6cc');fg.addColorStop(.6,sk);fg.addColorStop(1,'#cf9c70');
  [-1,1].forEach(k=>pap(()=>g.ellipse(k*31,2,6,10,0,0,7),sk,.3));pap(()=>g.ellipse(0,0,31,38,0,0,7),fg,.8);
  pap(()=>{g.moveTo(-34,-2);g.quadraticCurveTo(-38,-46,0,-46);g.quadraticCurveTo(38,-46,34,-2);g.quadraticCurveTo(28,-26,0,-28);g.quadraticCurveTo(-28,-26,-34,-2)},o.hair||'#2a2230',.4);
  if(o.bun)pap(()=>g.arc(0,-52,14,0,7),o.hair||'#3b2a22',.5);
  const bl=o.sleep||((t+(o.bo||0))%3.2)<.12;g.lineCap='round';
  [-1,1].forEach(k=>{const ex=k*12;g.strokeStyle='#2a1a1a';g.lineWidth=3;g.beginPath();g.moveTo(ex-8,-13);g.quadraticCurveTo(ex,-17,ex+8,-13);g.stroke();
   if(bl){g.beginPath();g.moveTo(ex-6,-3);g.lineTo(ex+6,-3);g.stroke()}else{g.fillStyle='#fff';g.beginPath();g.ellipse(ex,-3,7,4.5,0,0,7);g.fill();g.fillStyle='#3a2a20';g.beginPath();g.arc(ex,-3,3.3,0,7);g.fill();g.fillStyle='#fff';g.beginPath();g.arc(ex+1,-4,1,0,7);g.fill()}
   if(o.glasses){g.lineWidth=2.5;g.strokeStyle='#333';g.beginPath();g.arc(ex,-3,10,0,7);g.stroke()}});
  if(o.glasses){g.strokeStyle='#333';g.beginPath();g.moveTo(-2,-4);g.lineTo(2,-4);g.stroke()}
  g.strokeStyle='rgba(120,70,40,.5)';g.lineWidth=2.5;g.beginPath();g.moveTo(1,2);g.quadraticCurveTo(5,10,0,12);g.stroke();
  g.fillStyle='rgba(255,120,120,.18)';[-1,1].forEach(k=>{g.beginPath();g.ellipse(k*19,10,7,4,0,0,7);g.fill()});
  if(o.sleep){g.fillStyle='#8a3a3a';g.beginPath();g.ellipse(0,19,5,2.5+2*Math.abs(Math.sin(t*2.2)),0,0,7);g.fill()}else if(o.mouth||o.tool){g.fillStyle='#5a1a1a';g.beginPath();g.ellipse(0,22,8,3+6*Math.abs(Math.sin(t*20)),0,0,7);g.fill()}else{g.strokeStyle='#a0504a';g.lineWidth=3;g.beginPath();g.arc(0,17,8,.25,Math.PI-.25);g.stroke()}
  if(o.tool){const hw=Math.sin(t*28),H=[-28,38+hw*2],M=[2+hw*5,19];g.lineCap='round';
   if(o.tool==='b'){g.strokeStyle='#3da5e0';g.lineWidth=8;g.beginPath();g.moveTo(H[0],H[1]);g.lineTo(M[0],M[1]);g.stroke();g.strokeStyle='#fff';g.lineWidth=10;g.beginPath();g.moveTo(M[0]-2,M[1]+1);g.lineTo(M[0]+10,M[1]-2);g.stroke();g.fillStyle='#fff';[[-7,24,5],[8,27,4.5],[0,31,4],[14,22,3.5]].forEach(([dx,dy,r],i)=>{g.beginPath();g.arc(dx+hw*i,dy+Math.sin(t*6+i)*1.5,r,0,7);g.fill()})}
   else{g.strokeStyle='#b9c2cc';g.lineWidth=7;g.beginPath();g.moveTo(H[0],H[1]);g.lineTo(M[0]-1,M[1]);g.stroke();g.fillStyle='#d5dce3';g.beginPath();g.ellipse(M[0]+3,M[1]-1,8,5,-.3,0,7);g.fill()}
   g.save();g.translate(H[0],H[1]);g.fillStyle=sk;g.beginPath();g.ellipse(0,0,12,16,.4,0,7);g.fill();g.restore()}}
 g.restore()}
function momScr(t,t0,txt,o={}){g.save();decorK(t);shk(t,t0,18,.4);cam(t,[[t0,1.0,360,640],[t0+2,1.1,360,560]]);
 ppl(360,1190,2.5,Object.assign({t,apron:1,bun:1,mouth:1,pocket:1,shirt:'#d9778a',pants:'#6b4a3a',hair:'#3b2a22'},o));g.restore();
 if(txt)chip(txt,360,115,60,'#fff','#c0392b',eb(pr(t,t0,t0+.3)));flash(t,t0,.4,.15)}
const TCH={shirt:'#34476b',pants:'#3a3a48',hair:'#9a9aa4',glasses:1,pocket:1,hel:['#555a66','#f2c200']};
const rb=(x,y,w,h,r,c,l)=>pap(()=>g.roundRect(x,y,w,h,r),c,l==null?.4:l);
function floorTile(y,c1,c2,st){g.fillStyle=c1;g.fillRect(0,y,720,1280-y);g.strokeStyle=c2;g.lineWidth=2;for(let x=-300;x<1020;x+=st){g.beginPath();g.moveTo(360+(x-360)*.35,y);g.lineTo(x,1280);g.stroke()}for(let k=1;k<6;k++){const yy=y+(1280-y)*Math.pow(k/6,1.5);g.beginPath();g.moveTo(0,yy);g.lineTo(720,yy);g.stroke()}}
function decor0(t){grad('#232957','#343a78');
 rb(60,130,190,250,12,'#0d1233',.8);glow(155,230,150,'#9bb4ff',.6);g.fillStyle='#fff6d0';g.beginPath();g.arc(180,210,34,0,7);g.fill();g.strokeStyle='#7b4a2c';g.lineWidth=8;g.strokeRect(60,130,190,250);g.beginPath();g.moveTo(155,130);g.lineTo(155,380);g.moveTo(60,255);g.lineTo(250,255);g.stroke();
 rb(36,110,46,300,12,'#7a3d5c');rb(228,110,46,300,12,'#7a3d5c');g.strokeStyle='#caa46a';g.lineWidth=7;g.beginPath();g.moveTo(20,112);g.lineTo(290,112);g.stroke();
 rb(560,190,110,150,6,'#f2e2b0');g.fillStyle='#d4382c';g.beginPath();g.arc(615,250,24,0,7);g.fill();rb(580,290,70,10,3,'#555',.2);rb(580,310,50,8,3,'#888',.2);
 rb(440,520,240,12,4,'#7b4a2c',.6);['#d4382c','#2f7de1','#f2c200','#38a169','#9b59b6','#e67e22','#2f7de1','#d4382c','#f2c200','#38a169'].forEach((c,i)=>rb(450+i*22,470+(i%3)*6,18,50-(i%3)*6,3,c,.3));
 g.strokeStyle='#999';g.lineWidth=3;g.beginPath();g.moveTo(600,630);g.lineTo(600,655);g.moveTo(600,655);g.quadraticCurveTo(570,670,540,690);g.moveTo(600,655);g.quadraticCurveTo(630,670,660,690);g.stroke();
 pap(()=>{g.moveTo(545,692);g.lineTo(600,672);g.lineTo(655,692);g.lineTo(680,760);g.lineTo(645,772);g.lineTo(640,830);g.lineTo(560,830);g.lineTo(555,772);g.lineTo(520,760)},pat(PLD.red),.6);
 g.save();g.translate(600,586);g.scale(.52,.52);hatShape();g.restore();
 g.fillStyle='#4a3646';g.fillRect(0,960,720,320);g.strokeStyle='rgba(0,0,0,.25)';g.lineWidth=2;for(let y=990;y<1280;y+=34){g.beginPath();g.moveTo(0,y);g.lineTo(720,y);g.stroke()}
 rb(60,1040,600,70,35,'#7a3d5c');rb(120,1060,480,30,15,'#a85a80',.2);[540,580].forEach(x=>{g.fillStyle='#e0b46a';g.beginPath();g.ellipse(x,1180,28,11,0,0,7);g.fill()})}
function decor1(t){
 [[70,1,'#b7b0a5'],[640,.65,'#a89fa6']].forEach(([x,s,c])=>{rb(x-12*s,200+(1-s)*200,24*s,860,4,c,.3);rb(x-55*s,250+(1-s)*200,110*s,10*s,3,'#8f8a82',.3)});
 g.strokeStyle='#4a3a4a';g.lineWidth=2.5;[0,18,36].forEach(o=>{g.beginPath();g.moveTo(15,255+o*.3);g.quadraticCurveTo(300,330+o,625,330+o*.3);g.stroke();g.beginPath();g.moveTo(125,255+o*.3);g.quadraticCurveTo(400,310+o,740,360+o);g.stroke()});
 [['#2f5a45',560,740,110],['#3a6d50',500,790,90],['#2f5a45',690,780,100],['#3a6d50',220,830,80],['#2a4d3c',330,860,70],['#3a6d50',-10,800,100]].forEach(([c,x,y,r])=>{g.fillStyle=c;g.beginPath();g.arc(x,y,r,0,7);g.arc(x+r*.6,y+r*.3,r*.8,0,7);g.arc(x-r*.6,y+r*.35,r*.75,0,7);g.fill()});
 g.fillStyle='#56804a';g.fillRect(0,890,720,120);g.strokeStyle='#3f6a3a';g.lineWidth=3;for(let x=10;x<720;x+=38){g.beginPath();g.moveTo(x,960+(x%3)*10);g.lineTo(x-4,944+(x%3)*10);g.moveTo(x,960+(x%3)*10);g.lineTo(x+5,946+(x%3)*10);g.stroke()}
 g.fillStyle='#4a3f55';g.fillRect(0,1010,720,270);g.fillStyle='#d8d0c8';g.fillRect(0,1018,720,8);g.fillStyle='#9a8f98';g.fillRect(0,1026,720,14);g.fillStyle='rgba(255,255,255,.7)';for(let x=-((t*160)%200);x<720;x+=200)g.fillRect(x,1170,110,10)}
function decor2(t){grad('#ffe7b0','#f0a56a');for(let x=0;x<720;x+=90){g.fillStyle='rgba(255,255,255,.16)';g.fillRect(x,0,45,1280)}
 floorTile(960,'#d9a066','rgba(120,70,30,.3)',100);
 rb(290,150,150,210,10,'#9fd3f0',.8);glow(365,250,120,'#fff',.5);g.strokeStyle='#fff';g.lineWidth=6;g.beginPath();g.moveTo(365,150);g.lineTo(365,360);g.moveTo(290,255);g.lineTo(440,255);g.stroke();rb(268,140,32,240,8,'#e0707a');rb(430,140,32,240,8,'#e0707a');
 rb(30,230,210,270,18,'#cfe9f5',.8);g.strokeStyle='rgba(255,255,255,.7)';g.lineWidth=8;g.lineCap='round';g.beginPath();g.moveTo(70,430);g.lineTo(130,300);g.moveTo(110,460);g.lineTo(190,300);g.stroke();
 rb(20,780,230,36,10,'#f0f2f5',.5);rb(30,816,210,150,8,'#c58b5a',.6);g.fillStyle='#b27a4c';g.fillRect(133,830,4,120);g.strokeStyle='#aaa';g.lineWidth=7;g.beginPath();g.moveTo(135,780);g.lineTo(135,745);g.lineTo(165,745);g.stroke();rb(185,740,30,40,6,'#8fd0f0');
 g.strokeStyle='#555';g.lineWidth=5;g.beginPath();g.moveTo(480,200);g.lineTo(700,200);g.stroke();[510,570,640].forEach((x,i)=>{g.beginPath();g.moveTo(x,200);g.lineTo(x,230);g.stroke();rb(x-24,230,48,40,8,i==1?'#d4382c':'#b0b8c2')});
 pap(()=>g.arc(600,110,40,0,7),'#fff',.5);g.strokeStyle='#333';g.lineWidth=4;g.beginPath();g.moveTo(600,110);g.lineTo(600,84);g.moveTo(600,110);g.lineTo(620,118);g.stroke();
 rb(470,830,240,22,6,'#8a5a38',.6);rb(485,852,18,130,4,'#6b4326');rb(680,852,18,130,4,'#6b4326');rb(560,742,86,88,16,'#eceef2',.5);g.fillStyle='#e8473f';g.beginPath();g.arc(603,770,8,0,7);g.fill();rb(485,812,60,18,8,'#fff',.3);rb(650,816,40,14,6,'#f2c200',.3);
 for(let i=0;i<3;i++){const u=(t*.6+i/3)%1;g.globalAlpha=(1-u)*.6;g.strokeStyle='#fff';g.lineWidth=5;g.beginPath();g.moveTo(595+i*8,740);g.quadraticCurveTo(587+i*8,720-u*40,595+i*8,700-u*60);g.stroke()}g.globalAlpha=1}
function decor3(t){
 g.fillStyle='rgba(60,110,90,.35)';g.fillRect(0,720,720,240);g.fillStyle='#fffbe0';[[120,20],[400,20]].forEach(([x,y])=>g.fillRect(x,y,200,12));glow(220,26,180,'#fffbe0',.4);glow(500,26,180,'#fffbe0',.4);
 rb(90,70,74,100,4,'#f7c548');rb(190,90,100,76,4,'#6bb3e0');rb(320,60,90,90,4,'#e8737a');[0,1,2].forEach(i=>{g.fillStyle='rgba(255,255,255,.7)';g.fillRect(100,86+i*22,54,6)});
 g.strokeStyle='#c43b3b';g.lineWidth=3;g.beginPath();g.moveTo(40,40);g.quadraticCurveTo(360,100,560,45);g.stroke();
 rb(60,496,600,10,3,'#8a5a38',.5);rb(100,486,36,10,3,'#fff',.2);rb(150,488,24,8,2,'#d8b48a',.2);
 for(let i=0;i<4;i++){rb(30+i*180,850,140,16,4,'#b88a5a',.5);rb(46+i*180,866,10,90,3,'#6b4326',.3);rb(144+i*180,866,10,90,3,'#6b4326',.3);rb(50+i*180,800,60,50,6,'#8a6a4a',.3)}
 floorTile(960,'#9fbf9a','rgba(0,0,0,.12)',100);
 rb(30,430,50,48,6,'#c0702f');[[-20,-40],[10,-60],[35,-35]].forEach(([dx,dy])=>{g.fillStyle='#3a8a4a';g.beginPath();g.ellipse(55+dx,430+dy,14,30,dx*.03,0,7);g.fill()})}
function decor4(t){
 rb(40,170,280,260,8,'#4a5568',.6);g.fillStyle='rgba(0,0,0,.35)';for(let x=60;x<320;x+=26)for(let y=190;y<430;y+=26){g.beginPath();g.arc(x,y,3,0,7);g.fill()}
 [[70,200,'#c9d2da'],[120,210,'#e8473f'],[170,200,'#f2c200'],[220,215,'#c9d2da'],[270,205,'#2f7de1']].forEach(([x,y,c],i)=>{g.save();g.translate(x,y);g.rotate((i-2)*.06);rb(-6,0,12,110,4,c,.3);rb(-16,-22,32,26,8,c,.3);g.restore()});
 g.fillStyle='#333';g.fillRect(304,60,6,100);g.fillStyle='#3a3f4a';g.beginPath();g.moveTo(240,120);g.lineTo(380,120);g.lineTo(350,160);g.lineTo(270,160);g.fill();const gl=g.createLinearGradient(0,160,0,960);gl.addColorStop(0,'rgba(255,200,120,.4)');gl.addColorStop(1,'rgba(255,200,120,0)');g.fillStyle=gl;g.beginPath();g.moveTo(270,160);g.lineTo(350,160);g.lineTo(640,960);g.lineTo(-20,960);g.fill();
 rb(480,420,200,18,4,'#566176',.5);[0,1,2].forEach(i=>rb(500+i*60,360,50,60,4,['#c0702f','#d9a066','#8a5a38'][i],.3));
 [0,1,2].forEach(i=>{g.fillStyle='#1b1b20';g.beginPath();g.ellipse(620,930-i*40,64,24,0,0,7);g.fill();g.fillStyle='#444';g.beginPath();g.ellipse(620,926-i*40,32,10,0,0,7);g.fill()});
 g.fillStyle='#f2c200';g.fillRect(0,960,720,24);g.fillStyle='#222';for(let x=-40;x<760;x+=60){g.beginPath();g.moveTo(x,960);g.lineTo(x+30,960);g.lineTo(x+10,984);g.lineTo(x-20,984);g.fill()}
 rb(10,780,150,180,8,'#c0392b',.6);[0,1,2].forEach(i=>{rb(22,792+i*56,126,44,4,'#e05a4a',.3);rb(70,808+i*56,30,6,2,'#ddd',.2)})}
function decor5(t){grad('#7a4a8a','#e08a6a');glow(540,360,380,'#ffd9a0',.6);
 rb(430,160,220,300,12,'#ffb86b',.7);glow(540,310,150,'#fff0c0',.8);g.fillStyle='#e0507a';g.beginPath();g.arc(540,400,60,Math.PI,0);g.fill();g.strokeStyle='#4a2d58';g.lineWidth=8;g.strokeRect(430,160,220,300);g.beginPath();g.moveTo(540,160);g.lineTo(540,460);g.stroke();
 rb(406,140,26,340,8,'#8a3d5c');rb(648,140,26,340,8,'#8a3d5c');
 rb(30,330,140,560,10,'#4a2d58',.8);rb(48,350,104,250,6,'#5a3868');g.fillStyle='#e8c46a';g.beginPath();g.arc(140,640,8,0,7);g.fill();
 rb(200,200,70,90,4,'#f2e2b0');rb(215,215,40,40,4,'#d9778a',.3);rb(290,230,60,70,4,'#f2e2b0');rb(302,242,36,36,4,'#6bb3e0',.3);
 rb(40,900,200,18,6,'#6b4326',.5);[[60,'#d4382c'],[130,'#2f7de1'],[190,'#f2c200']].forEach(([x,c])=>{g.fillStyle=c;g.beginPath();g.ellipse(x,892,28,12,0,0,7);g.fill()});
 floorTile(990,'#6a3d70','rgba(0,0,0,.18)',100);
 rb(560,780,60,60,8,'#c0702f');[[-18,-30],[10,-55],[34,-28]].forEach(([dx,dy])=>{g.fillStyle='#3a8a4a';g.beginPath();g.ellipse(590+dx,780+dy,14,32,dx*.03,0,7);g.fill()})}
function decorK(t){grad('#ffd9a0','#e48a5a');glow(360,500,520,'#fff3c0',.6);
 [0,1,2,3].forEach(i=>{rb(20+i*180,60,160,160,10,'#c58b5a',.6);rb(40+i*180,80,120,120,6,'#d9a066',.3);rb(70+i*180,205,60,8,3,'#6b4326',.3)});
 g.strokeStyle='#555';g.lineWidth=5;g.beginPath();g.moveTo(20,300);g.lineTo(700,300);g.stroke();[60,150,260,520,600].forEach((x,i)=>{g.beginPath();g.moveTo(x,300);g.lineTo(x,330);g.stroke();rb(x-22,330,44,i%2?34:50,8,i%2?'#b0b8c2':'#e0707a')});
 g.fillStyle='#f4d6a8';g.fillRect(0,880,720,400);g.fillStyle='#c9693f';g.fillRect(0,860,720,24);rb(30,830,150,120,10,'#d9d9de',.5);[0,1].forEach(i=>{g.fillStyle='#444';g.beginPath();g.arc(70+i*70,860,18,0,7);g.fill()});rb(520,800,170,150,10,'#eceef2',.5)}
function bed(t){const br=Math.sin(t*2.2)*3;g.save();groundShadow(360,1020,320,.35);
 pap(()=>g.roundRect(30,690,80,330,18),'#7b4a2c',1);pap(()=>g.roundRect(660,850,30,170,8),'#6b3f26',1);pap(()=>g.roundRect(60,900,620,90,18),'#8a5a38',1);pap(()=>g.roundRect(70,830,600,90,34),'#f4f1ea',1);pap(()=>g.roundRect(100,790,170,70,34),'#ffffff',.8);
 g.save();g.translate(560,782+br);g.rotate(-Math.PI/2);ppl(0,0,1,{t,sleep:1,pocket:1,noshadow:1,shirt:'#7a8fb5',pants:'#4a5578'});g.restore();
 pap(()=>{g.moveTo(470,846);g.quadraticCurveTo(480,758,540,756);g.quadraticCurveTo(600,748,646,764);g.lineTo(656,846)},'#3f7fd0',1);g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=10;g.beginPath();g.moveTo(480,800);g.quadraticCurveTo(560,780,650,800);g.stroke();g.restore()}
function s0(t){g.save();drift(t,5);cam(t,[[CD(0),1.3,360,640],[CD(2),1.0,360,640]]);
 grad('#161a40','#3b2f72');glow(540,300,300,'#9bb4ff',.5);
 [[90,160],[200,300],[620,130],[470,420],[300,110]].forEach((p,i)=>{g.fillStyle='#fff';g.globalAlpha=.5+.5*Math.sin(t*3+i);g.beginPath();g.arc(p[0],p[1],3+i%2*2,0,7);g.fill()});g.globalAlpha=1;
 decor0(t);dust(t,14,'rgba(200,210,255,.5)',10);
 const q=.5+.5*eb(pr(t,0,.5));g.save();g.translate(360,380);g.scale(q,q);if(t>CD(2))g.rotate(Math.sin(t*70)*.05);
 [-1,1].forEach(k=>pap(()=>g.arc(k*96,-140,38,0,7),'#c23a33',.6));pap(()=>g.arc(0,0,150,0,7),'#e8473f',1.2);pap(()=>g.arc(0,0,118,0,7),'#fff6e0',.3);tx('05:00',0,6,72,'#222',{w:700});g.restore();
 bed(t);
 for(let i=0;i<3;i++){const u=(t*.6+i/3)%1;g.globalAlpha=1-u;tx('Z',210+i*26+u*30,700-u*150-i*10,40+i*14,'#cfe0ff',{s:'#223',sw:6})}g.globalAlpha=1;
 g.restore();flash(t,CD(0),.5,.2)}
function s1(t){g.save();shk(t,CD(6),16,.4);drift(t,4);cam(t,[[CD(3),1.0,360,640],[CD(6)-.5,1.18,360,720],[CD(6)+.4,1.0,360,640]]);
 grad('#ffb870','#d65f8e');glow(360,520,420,'#fff1b0',.7);clouds(t,200,'rgba(255,230,230,.7)',12);
 hills(700,40,.005,'#b4547a',-10,t);hills(800,34,.007,'#8f3f6e',-30,t,1);wl(1010,16,.01,'#5b2c55',t*40,1);dust(t,16,'rgba(255,240,200,.6)',-30);decor1(t);
 const dn=t>=CD(6),T0=CD(3)+.9,T1=CD(4)+.45,hu=pr(t,T0,T1),landed=t>=T1,held=t<T0,since=t-T1;
 ppl(360,1000,1.2,{t,walk:!dn,dance:dn?1:.55,pocket:!dn,hold:held,holdK:eb(pr(t,CD(3),CD(3)+.25)),hat:landed,tilt:landed&&since<.7?-.2*Math.sin(Math.PI*Math.min(1,since/.7)):0,shirt:'#4a3330'});
 if(!held&&!landed){const e=hu,sc=.57+.19*e;g.save();g.translate(286+74*e,818+(544-818)*e-Math.sin(e*Math.PI)*330);g.rotate(e*Math.PI*4);g.scale(sc,sc);hatShape();g.restore()}
 if(landed&&since<.6){burst(t,T1,360,554,'#ffffff',12,150);flash(t,T1,.3,.25)}
 if(dn){const k=eb(pr(t,CD(6),CD(6)+.4));g.save();g.translate(360,330);g.rotate(-.06);g.scale(k,k);tx('ต้องซอย!',0,0,120,'#fff',{s:'#b21f4a',sw:26,w:700});g.restore();burst(t,CD(6),360,330,'#ffd23a',16,260)}
 wl(1230,10,.015,'#3a1c3a',t,1);g.restore();flash(t,CD(3),.4,.16);flash(t,CD(6),.5,.18)}
function s2(t){if(t>=CD(9)&&t<CE(10)+.1){momScr(t,t>=CD(10)?CD(10):CD(9),t>=CD(10)?'เดี๋ยวก็สาย!':'ลูกกก!!');return}
 g.save();drift(t,4);cam(t,[[CD(7),1.0,360,640],[CE(8),1.1,330,700]]);
 decor2(t);
 ppl(300,1000,1.15,{t,dance:1,tool:t<CD(8)?'b':(t<CD(9)?'s':0),bowl:t>=CD(8)&&t<CD(9),shirt:'#4a3330'});
 if(t>=CD(11)){const k=eb(pr(t,CD(11),CD(11)+.3));chip('ลูกกก!!',560,560,52,'#fff','#c0392b',k*(.9+.1*Math.sin(t*BT)))}
 g.restore();flash(t,CD(7),.4,.16)}
function s3(t){g.save();drift(t,4);shk(t,CD(14),10,.3);cam(t,[[CD(12),1.0,360,640],[CD(14),1.0,360,640],[CD(14)+.3,1.12,300,760],[CD(17),1.0,360,700]]);
 grad('#cfe8d6','#a7d1b6');pap(()=>g.roundRect(60,200,600,300,18),'#2f5d4a',1);g.strokeStyle='#e8f4ea';g.lineWidth=5;g.lineCap='round';
 tx('วงจรไฟฟ้า',360,262,52,'#f1f7f0');g.beginPath();g.rect(220,320,280,120);g.stroke();g.beginPath();g.arc(360,440,22,0,7);g.stroke();tx('⚡',360,380,40,'#ffd23a');
 pap(()=>g.roundRect(560,80,100,100,50),'#fff',.6);g.strokeStyle='#333';g.beginPath();g.moveTo(610,130);g.lineTo(610,95);g.moveTo(610,130);g.lineTo(635,135);g.stroke();
 wl(1000,12,.01,'#8ab89a',t,1);dust(t,10,'rgba(255,255,255,.6)',6);decor3(t);
 const kd=t>=CD(14),fd=t>=CD(16),td=t>=CD(17)+.9;
 ppl(150,1010,1.1,{t,dance:kd?1:0,pocket:!kd,hat:1,shirt:'#4a3330'});
 ppl(290,1010,.95,{t,dance:fd?1:0,pocket:!fd,hat:fd,shirt:'#e07a5f',plaid:PLD.bw,bo:1,hel:['#2a2a30','#e0463c']});ppl(430,1010,.95,{t,dance:fd?1:0,pocket:!fd,hat:fd,shirt:'#5fa8d3',plaid:PLD.pink,bo:2,hel:['#e8edf2','#2f7de1']});
 ppl(600,1010,1.05,Object.assign({t,dance:td?1:0,hat:td},TCH,{pocket:!td}));
 if(t>CD(13)){const k=eb(pr(t,CD(13),CD(13)+.4));chip('ใครตอบได้?',600,500,44,'#fff','#2a3a5a',k)}
 if(t>CD(15)&&t<CD(16)){g.save();g.translate(600,470);g.rotate(Math.sin(t*9)*.15);tx('?',0,0,120,'#fff',{s:'#222',sw:16});g.restore()}
 if(t>CD(17)&&t<CD(17)+.9){const u=pr(t,CD(17),CD(17)+.9);g.save();g.translate(620,700+u*300);g.rotate(u*6);pap(()=>g.roundRect(-5,-30,10,60,4),'#222',.3);g.restore()}
 if(t>CD(17)+.9)burst(t,CD(17)+.9,600,640,'#ffd23a',14,200);
 g.restore();flash(t,CD(12),.4,.16)}
function s4(t){g.save();drift(t,4);const mt=t>CD(20)+.2&&t<CE(20)-1,ok=t>=CE(20)-1;shk(t,CD(20)+.2,8,.3);cam(t,[[CD(18),1.0,360,640],[CD(20),1.15,400,760],[CD(22),1.0,360,700]]);
 grad('#3a4252','#1f2430');glow(480,700,420,'#ff9a3c',.35);[300,460].forEach(y=>pap(()=>g.roundRect(30,y,200,16,4),'#566176',.5));hills(990,14,.01,'#2a303d',8,t);wl(1010,8,.012,'#1a1e29',t,1);dust(t,12,'rgba(255,190,110,.6)',-6);decor4(t);
 const hop=t>=CD(22)?-Math.abs(Math.sin(t*BT))*34:0;g.save();g.translate(470+(mt?Math.sin(t*60)*7:0),880+hop);if(t>=CD(22))g.rotate(Math.sin(t*BT*.5)*.09);groundShadow(0,12,150,.35);
 pap(()=>g.roundRect(-130,-250,260,260,24),'#5c7a8c',1);pap(()=>g.arc(-40,-150,56,0,7),'#34495e',.5);g.save();g.translate(-40,-150);g.rotate(t*(mt?14:3));for(let i=0;i<4;i++){g.rotate(1.571);pap(()=>g.ellipse(0,-30,14,30,0,0,7),'#9fb3c1',.3)}g.restore();
 g.fillStyle=ok?'#38d66b':(mt?'#ff4d3a':'#7a2a2a');g.beginPath();g.arc(70,-200,16,0,7);g.fill();if(ok)glow(70,-200,90,'#38d66b',.6);
 if(t>=CD(22)){g.save();g.translate(0,-250);hatShape();g.restore()}g.restore();
 if(mt){burst(t,CD(20)+.2,470,700,'#ffd23a',12,160);burst(t,CD(20)+1.2,470,700,'#ffd23a',12,160)}if(ok)burst(t,CE(20)-1,540,680,'#38d66b',16,220);
 const kd=t>=CD(19);ppl(210,1010,1.15,{t,wrench:1,dance:kd?1:0,pocket:!kd,hat:1,shirt:'#4a3330'});
 if(t>=CD(21)){const x=600+(1-ez(t,CD(21),CD(21)+.7))*260;ppl(x,1010,1.05,Object.assign({t,walk:t<CD(21)+.7},TCH));if(t<CD(22))chip('ซ่อมยังไง?',x,500,44,'#fff','#2a3a5a',eb(pr(t,CD(21)+.6,CD(21)+1)))}
 if(t>=CD(22)&&t<CD(22)+1.6){g.save();g.translate(210,430);g.rotate(Math.sin(t*9)*.1);tx('ไม่รู้ครับ',0,0,50,'#fff',{s:'#222',sw:12});g.restore()}
 g.restore();flash(t,CD(18),.4,.16)}
function s5(t){const f=t>=CD(27);if(t>=CD(24)&&t<CD(25)){momScr(t,CD(24),'วันนี้เรียนอะไร?');return}if(t>=CD(26)&&t<CD(27)){const h=t>=CD(26)+.9;momScr(t,CD(26),'ซอยก็ซอยลูก!',h?{hat:1,dance:1,pocket:0,mouth:0}:{});if(h)burst(t,CD(26)+.9,360,300,'#ffd23a',16,260);return}
 g.save();drift(t,4);
 if(!f){cam(t,[[CD(23),1.0,360,640],[CD(25),1.1,360,700]]);decor5(t);
  if(t<CD(24))ppl(-60+ez(t,CD(23),CD(24))*430,1000,1.2,{t,walk:1,dance:.55,pocket:1,hat:1,shirt:'#4a3330'});else ppl(360,1020,1.5,{t,dance:1,hat:1,shirt:'#4a3330'})}
 else{grad('#f6c88a','#e0709a');rays(t,360,640,'#ffffff',.5);confetti(t);const k=eb(pr(t,CD(27),CD(27)+.5));g.save();g.translate(360,300);g.scale(k,k);g.rotate(Math.sin(t*BT)*.04);tx('จะซอยไหม?',0,0,92,'#fff',{s:'#7a2a4a',sw:24,w:700});g.restore();
  [[130,'#4a3330',1],[270,'#e07a5f',0],[410,'#5fa8d3',0],[560,'#d9778a',0]].forEach((p,i)=>ppl(p[0],900,.78,{t:t+i*.1,dance:1,hat:1,shirt:p[1],plaid:[PLD.red,PLD.bw,PLD.pink,null][i],bun:i==3,apron:i==3}))}
 g.restore();flash(t,CD(23),.4,.16);flash(t,CD(27),.5,.18)}
const SC=[[CD(0),s0],[CD(3),s1],[CD(7),s2],[CD(12),s3],[CD(18),s4],[CD(23),s5]];
const EMO=['','','','','','','','','','','','','','','','','','','','','','','','','','','','',''];
const KWS=['ซอย','จิ๊กโก๋','หมวก'];
