/* Starter scenes (detailed 3D-look). Copy to <project>/scenes.js, keep the structure, change story/visuals.
   Every visual is tied to a caption card: CD(k) = start of card k, CE(k) = end. Never raw seconds.
   Use rig.js: ppl() for EVERY character, ROOM.* presets or floor()+props for EVERY set (see references/rig.md). */
function hook(t){g.save();drift(t,4);shk(t,CD(0),16,.4);cam(t,[[CD(0),1.25,360,700],[CE(1),1.0,360,640]]);
 ROOM.classroom(t);ppl(360,1190,2.3,{t,hat:1,plaid:PLD.red,pocket:1,mouth:1});g.restore();
 const q=eb(pr(t,CD(0),CD(0)+.45));g.save();g.translate(360,170);g.scale(q,q);tx('หัวข้อใหญ่',0,0,104,'#fff',{s:'#a51931',sw:22});g.restore();flash(t,CD(0),.4,.15)}
function middle(t){g.save();drift(t,4);cam(t,[[CD(2),1.0,360,640],[CE(3),1.18,330,700]]);
 ROOM.street(t);ppl(250,1200,2.0,{t,walk:1,plaid:PLD.pink,pocket:1,hair:'#2a2230'});ppl(520,1190,1.9,{t,shirt:'#34476b',pants:'#3a3a48',hair:'#9a9aa4',glasses:1,pocket:1});g.restore();
 if(t>CD(3))chip('จุดสำคัญ',360,170,60,'#d9a52a','#4a2a10',eb(pr(t,CD(3),CD(3)+.5)));burst(t,CD(3),360,520,'#ffd23a')}
function outro(t){g.save();drift(t,4);cam(t,[[CD(4),1.0,360,640],[CE(4),1.12,360,700]]);
 ROOM.workshop(t);ppl(300,1200,2.2,{t,wrench:1,plaid:PLD.bw,pocket:1,mouth:1});g.restore();
 const q=eb(pr(t,CD(4),CD(4)+.6));g.save();g.translate(360,170);g.scale(q,q);tx('คุณคิดว่าไง?',0,0,92,'#fff',{s:'#7a2a4a',sw:20});g.restore()}
const SC=[[CD(0),hook],[CD(2),middle],[CD(4),outro]];
const EMO=['🔥','🤔','💡','❓','😮'];          // one per card ('' = none)
const KWS=['หัวข้อ','จุดสำคัญ'];             // words highlighted in yellow in captions
