# rig.js API (detailed 3D-look people, floors, props, rooms)
Everything is already inlined by `build_video.py`. Never draw stick figures, blobs or flat color boxes for characters or sets.

## People: `ppl(x, y, scale, opts)`  (x,y = feet; scale ~1.9-2.5 for hero, ~1.6-2.0 for background)
Shaded jeans/shirt/face, blinking eyes, arms, shoes, ground shadow. `opts`:
- `t` (always pass), `walk:1`, `dance:1`, `flip:1`, `tilt`, `noshadow:1`
- look: `shirt:'#hex'` or `plaid:PLD.red|PLD.bw|PLD.pink`, `pants`, `skin`, `hair`, `bun:1`, `glasses:1`, `apron:1`, `pocket:1`, `hat:1` (white visor helmet; `hel:[c1,c2]`)
- action: `mouth:1` (talking), `sleep:1`, `tool:'b'|1` (brushing/tool at mouth), `wrench:1` (raises a wrench), `hold:1` (holds helmet)
- Give every character a different look (shirt/plaid + hair + accessory). Split voices: one character per speaker.

## Rooms (full detailed sets): `ROOM.<name>(t)` then draw `ppl(...)` on top
`bedroom` (night window, bookshelf, poster) · `street` (poles, wires, bushes, road) · `kitchen` (window, shelves, stove, table) · `classroom` (board area, notes, desks) · `workshop` (pegboard tools, spotlight, tyres, hazard floor, cabinet) · `sunset` (warm hall, door, shelves) · `home` (kitchen sunset). Presets are the approved quality bar; for a new place build a custom set (below).

## Custom set recipe (>= 6 props + floor + light, never an empty wall)
```js
grad('#ffe7b0','#f0a56a');                    // wall
windowP(260,160,170,220,0,t); clockP(560,130,44,t); shelfP(40,300,200); plantP(560,820,1.2);
boardP(60,380,420,240,'วงจรไฟฟ้า'); pegP(40,170,280,260); tableP(470,830,240); crateP(600,880); spotP(300,160,300);
floor('wood',860,{t});                         // kinds: wood tile carpet road hazard grass concrete (y = horizon)
ppl(360,1180,2.2,{t,...});
```
Props: `windowP(x,y,w,h,night,t)` `clockP(x,y,r,t)` `shelfP(x,y,w)` `plantP(x,y,s)` `boardP(x,y,w,h,text)` `pegP(x,y,w,h)` `spotP(x,y,x2)` `tableP(x,y,w)` `crateP(x,y,s)`; helpers `rb(x,y,w,h,r,color,shadow)` (rounded box with paper shadow), `bed(t)`, `pat(PLD.x)` (plaid pattern fill).
Floor: `floor(kind,y,{t,st,light:{x,r,col,a}})` perspective planks/tiles, contact shadow under the wall, light pool.

## Speed: cache busy static sets
`layer('key',()=>setDraw(0))` draws a static set once into an offscreen canvas, then 1 `drawImage` per frame (a 24-bottle cooler + shelves went 94 -> 50 ms/frame). Put people, clocks, steam, anything using `t` outside it. Use it for any custom set with many props; `frame_cost.js` WARN means do this first.

## With the camera
Wrap the set + people in `g.save(); drift(t,4); cam(t,[[CD(k),1.2,360,700],[CE(k+1),1.0,360,640]]); … g.restore();` then draw titles/chips outside it. Ground characters at y ~1180-1200 (feet), floor horizon ~860-990.
