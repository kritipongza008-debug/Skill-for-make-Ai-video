# Publishing the video page

- One self-contained HTML (`out/video.html`), audio inline as base64 (2 tracks). Limit 16 MB; a 63 s clip ≈ 2.7 MB.
- Allowed external resources only: Google Fonts stylesheet (used for Mitr) and the listed CDNs. No remote images/scripts.
- The page needs the **downloads** capability to save the MP4: call `Artifact` action `capabilities` before the first publish and pass `capabilities: {"downloads": true}`; the page calls `claude.use('downloads')` and falls back to an `<a download>` link.
- Update an existing artifact by passing its `url` (same link stays valid).
- `MediaRecorder` records the canvas + the audio graph in real time (clip length). Chrome/Safari record MP4 (H.264/AAC); Firefox falls back to WebM — the UI says so. Keep the tab in the foreground while recording.
- Browser storage is not used. No network calls.
- Use `view` on `preview/sheet.png` (headless frames) before publishing; the preview has no emoji and no audio.
