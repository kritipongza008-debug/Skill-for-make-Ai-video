# SFX & music

All sounds are synthesized offline by `scripts/bake_audio.js`; list types with `node scripts/bake_audio.js --list`. Cues live in `cues.json`: `[cardIndex, offsetSeconds, "type", param?]`, time = start of card + offset.

## Design rules
1. A cue exists only for something the viewer can see happen (stamp lands, piece tears off, number changes).
2. Different events → different types or pitches. Max ~8 cues / 10 s, at most 3 `swoosh`/`whooshd`; no two cues closer than 0.25 s.
3. Impact on the frame the visual lands: for events inside a long card, estimate the offset from the card's start and the position of the word in the phrase; re-check by scrubbing.
4. Silence is a tool: leave the hook line and the final line clean.
5. Mood: `warm` (documentary/friendly), `mystery` (beliefs, night), `bright` (kids). `music.bpm` 70–100.

## Suggested mapping
| Event | Cue |
|---|---|
| object appears / chip pops | `pop` (vary freq 420–900) |
| stamp / treaty / verdict | `stamp` (80–210 Hz), `gavel` |
| tear / cut / piece falls | `tear` (2200–3400), `snip` |
| reveal / success | `chime`, `ding`, `sparkle`, `fan` (finale only) |
| warning / danger | `sting`, `horn`, `alarm`, `buzz` |
| water / nature | `bubbles`, `splash`, `gulp` |
| time passing | `tick`, `dong` (final zero) |
| squeeze / pressure | `push` then `bump` |

## Levels (measured by mix_audio.py → levels.json)
Voice mean ≈ −23 dB. Music ducked ≈ −33 to −38 dB under speech (≈ 10–15 dB below). SFX peaks ≈ −6 dB. Mixed peak < −0.3 dB (limiter at 0.95). Change `config.json → mix`: `music_volume`, `duck_ratio`, `duck_threshold`, `sfx_volume`.

## Page toggle
The page embeds two tracks: mixed (voice+music+SFX) and voice-only; the "เพลง+เอฟเฟกต์" button swaps before playback. Effects are **baked into the audio file**: do not synthesize them in the browser (a runtime version silently produced no sound for one user; see pitfalls).
