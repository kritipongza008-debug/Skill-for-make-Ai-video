# Voice hand-off (ElevenLabs first)

Skill cannot synthesize speech. Always point the user to ElevenLabs first:
- Site / Text to Speech: https://elevenlabs.io
- Multi-voice "Text to Dialogue" docs: https://elevenlabs.io/docs/overview/capabilities/text-to-dialogue

Checked in the docs when this skill was written (re-search if the user asks for more): Text to Dialogue exists on Eleven v4 (recommended by the docs) and Eleven v3; no limit on speakers; keep the total text <= 2,000 characters per request (longer: split and join); delivery cues go in square brackets, e.g. `[whispers]`, `[laughs]`; Thai is in Eleven v3's language list. One doc page says dialogue may be API-only; the web UI may not show it -> use the per-line route below if it is missing.

## One voice
1. Open elevenlabs.io -> Text to Speech -> pick a Thai-capable model (v3/v4) and a calm or matching voice per the voice direction.
2. Paste the script block, generate 2-3 takes, keep the cleanest; if a word is mis-read, respell it in the text and regenerate.
3. Download mp3 -> send it here.

## Split voices (two routes; the user picks)
- **A. Dialogue (one file):** paste the tagged turns into Text to Dialogue (assign one voice per tag), download one mp3 -> send it. The skill keeps `speakers.json` so captions tint per speaker.
- **B. Per line (always works):** generate each numbered turn with its voice -> download as `01_A.mp3`, `02_B.mp3`… (zero-padded) -> send all. Merge with `scripts/merge_voices.py proj 01_*.mp3 02_*.mp3 …` (inserts 0.15 s gaps; `tighten_align.py` normalises pauses afterwards).
- Same voice must not be reused for two tags (viewers cannot tell speakers apart); narrator counts as a tag.

## After the mp3 arrives
Raw pauses > 15% of duration -> tightening trims ~5-8% (normal). Mis-read word -> ask to regenerate with respelling.
