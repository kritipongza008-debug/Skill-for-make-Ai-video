# Pitfalls (symptom -> cause -> fix)
| Symptom | Cause | Fix |
|---|---|---|
| Saved MP4 freezes late in the clip, page was fine | recording draws + encodes at once; heavy frames (shadowBlur, full-screen grain, 60 fps draw) stall the canvas while audio keeps going; also tab switch/lock screen pauses drawing | core is lean now (hard shadows, no grain, 30 fps, 3 Mbps, 1 s chunks); run `frame_cost.js`; keep tab in front |
| Centered text drawn left-aligned in some browsers | `textAlign:'center'` | `tx` measures width and aligns itself (already in core) |
| Preview frames identical after one scene | `g.scale(0,0)` breaks node-canvas permanently | `eb` floors at .001; never scale by 0 |
| Pango "size >= 0" | animated font size 0/negative | clamp sizes >= 1 |
| Partial preview | piping node output into `head` (SIGPIPE) | write to files |
| Captions drift from speech | uniform chars/s mapping | `tighten_align.py` DP alignment (still an estimate) |
| User heard no SFX | live WebAudio effects | bake effects + music into mixed.mp3 |
| Thai words split on wrap | no spaces in Thai | put `\n` in cards by hand |
| `mkdir -p d/{a,b}` makes literal dir | sh has no brace expansion | use bash |
| Duplicate `const SC` | old + new scene files concatenated | one `scenes.js` per project |
| Several voice files out of order | shell sort of unpadded names | zero-pad: 01_A, 02_B… |
| `--no-audio` page stuck on frame 0 | stub audio data is not a playable file, so `au.play()` never advances `currentTime` or fires `ended` | fixed: `build_video.py --no-audio` embeds a real silent mp3 of the right length; verify with `ffprobe` on the embedded audio |
