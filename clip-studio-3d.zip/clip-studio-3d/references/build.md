# BUILD mode (voice mp3 -> finished page)

```bash
S=<skill>/scripts
bash $S/setup.sh                       # once per container (ffmpeg, node, canvas in ~/.svs)
python3 $S/new_project.py proj --script script.txt --title "ชื่อคลิป"   # split voices: tagged [A] [B] lines -> speakers.json + config.speakers
# several turn files? -> python3 $S/merge_voices.py proj 01_*.mp3 02_*.mp3 ...   (else: cp voice.mp3 proj/voice.mp3)
# 1 edit proj/cards.json: one card = one spoken phrase, "\n" breaks lines (<= ~24 chars/line, never split a Thai word)
python3 $S/tighten_align.py proj       # trims pauses, aligns cards -> voice_t.wav, timeline.json
# 2 write proj/scenes.js (ties to CD(k)/CE(k), never raw seconds; start from assets/starter_scenes.js)
# 3 write proj/cues.json [[cardIndex,offsetSec,"type",param?]...]   (node $S/bake_audio.js --list)
node $S/bake_audio.js proj && python3 $S/mix_audio.py proj
python3 $S/build_video.py proj --no-audio && node $S/render_preview.js proj   # LOOK at preview/sheet.png
node $S/frame_cost.js proj             # smoothness: want OK (median <= 60 ms in node-canvas)
python3 $S/build_video.py proj         # out/video.html (audio embedded, syntax-checked)
python3 $S/audit_video.py proj         # audit.md: fix FAILs, report WARNs
```
Expect 2-3 rebuild loops; stop at 3. Do not pipe render output into `head`.

## The look (always the same 3D-look paper-cut)
**Characters and sets must come from `lib/rig.js`** (read `references/rig.md`, ~1 page): `ppl()` for every character, `ROOM.*` presets or `floor()` + props for every set. Never stick figures, blobs, flat boxes or empty walls. Read `references/polish-guide.md` once, `references/visual-recipes.md` only if you need a technique, and at most ONE scene of `assets/examples/dekchang_scenes.js` as the quality bar (never paste it).
- Every set: >= 6 props + a `floor()` + light; every character shaded and animated; different look per character.
- >= 4 depth layers per scene (parallax `hills`, glow, ground, foreground, `dust`); `drift(t)` + `groundShadow`; `cam()` push/pan in every scene.
- Characters animate (bob, blink, walk, reaction); each spoken idea is a visual metaphor, not a text chip; a new visual element on almost every card.
- Hook (card 0-1): motion + pattern break on frame 1 (stamp, tear, countdown, punch-in), never an empty frame or title card.
- Impacts: `shk` + `burst` + `flash` + a baked cue on the same frame. Cues <= ~8 per 10 s, <= 3 swooshes, varied (`references/sfx-and-music.md`).
- Captions stay out of the bottom ~20% (`capY` 960), titles out of the top ~10%. `eb()` for pop-ins (never scale 0), font sizes >= 1.
- End on a question continuing line 1; `config.loop` crossfades the last 0.7 s.
- Split voices: captions auto-tint per speaker (`config.speakers[].color`); give each speaker its own character/position on screen.
- Performance (mandatory): no `shadowBlur` (core uses hard offset shadows), paper grain is one cached `drawImage` (leave on; `config.grain:false` turns it off), no other full-screen overlays per frame, <= ~150 fills per frame in busy scenes, cap confetti/dust counts. Cache busy static sets with `layer()` (`references/rig.md`). Re-run `frame_cost.js` after heavy scenes.

## Publish
`Artifact` action `capabilities` first (downloads must be declared) -> publish `out/video.html` with `capabilities:{"downloads":true}`; later changes: same `url`. < 16 MB. Details `references/publishing.md`. Tell the user: keep the tab in the foreground while saving; close heavy tabs.

## Standard check before "done" (lean)
`audit_video.py` clean of FAIL + one look at `preview/sheet.png` + `frame_cost.js` not FAIL. For the full pass see `deep-check.md`.
