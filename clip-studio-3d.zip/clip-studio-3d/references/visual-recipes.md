# Visual recipes (canvas 720×1280, paper-cut style)

Core helpers are in `assets/lib/core.js` (read its header). Patterns that worked:

| Need | Recipe |
|---|---|
| Camera push/pan | `g.save();cam(t,[[CD(a),1,360,640],[CE(b),1.2,400,560]]);…world…;g.restore()` |
| Pop-in | `const k=eb(pr(t,t0,t0+.5));g.translate(x,y);g.scale(k,k)`; `eb` never returns 0 |
| Paper-cut piece | `pap(()=>{g.moveTo..;g.lineTo..},'#color',shadow)` (soft drop shadow + white edge) |
| Layered waves | `wl(y,amp,freq,color,phase)` stacked 3× with different colours |
| Tear transition | clip left/right halves with a zig-zag polygon, rotate+translate each away, reveal below |
| Countdown spine | `overlay(t)` draws a top bar from remaining time; colour green→yellow→red |
| Split screen | two `pap(roundRect)` cards sliding from opposite sides + "VS" chip |
| Stamp | scale from 2.2→1 with `eb`, rotate −0.2, red ring + text |
| Real geography | download Natural Earth GeoJSON (raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_10m_admin_0_countries.geojson and `_admin_1_states_provinces`), equirectangular projection, Douglas-Peucker simplify (tolerance 0.5–1 px; split closed rings at the farthest point first), embed as flat arrays. Hand-drawn "country-like blobs" were rejected by the user: use real data for maps. |
| Characters | draw with legs, arms, hands, face; people without legs/arms looked wrong to the user. Prefer objects/animals/icons when characters are not essential. |
| Emoji | fine in the browser but invisible in the headless preview; do not depend on them for meaning |

## Layout rules
- Chips/titles y ≥ 130 (top 10% reserved), captions baseline `capY` (≈960). Keep key objects between y 250 and 900.
- Text > 650 px wide is auto-shrunk in captions; for your own `tx` calls measure with `g.measureText`.
- Each scene: background, mid-ground event, foreground accent, camera move. Crossfade between scenes is automatic (0.4 s).

## Perf
~1 ms/frame for paper layers; avoid per-frame `createRadialGradient` in loops of >50 items; shadows (`shadowBlur`) are the most expensive operation.

## v2 helpers (core.js)
`shk` shake · `flash` · `drift` · `rollNum` · `hills` parallax · `groundShadow` · `glow` · `dust` · `burst` · `clouds` · `sweat`. Full usage and the polish checklist: `polish-guide.md`. Reference implementation (animated rex, balance scale, stomp, clock): `assets/examples/trex_scenes_v2.js`.
