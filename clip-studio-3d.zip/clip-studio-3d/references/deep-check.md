# DEEP CHECK (trigger: "ต้องตรวจให้ละเอียดก่อนส่ง", or a request to review/improve)

Goal: check every frame-level detail and **fix and upgrade** the clip until it matches the quality bar of `assets/examples/dekchang_scenes.js`. Applies to a clip you built or one the user uploads (HTML). Spend tokens here only; the standard check stays light.

## Protocol
1. **Measure**: `audit_video.py proj` (hook, pacing, captions, sound, ending, renderer), `frame_cost.js proj` (smoothness). For an uploaded HTML without project files, extract its scenes and rebuild a project, or review by hand with the checklist below.
2. **Look at frames**: render `preview/sheet.png`, then single frames at *every card start* and 0.2 s before every card end (`node scripts/render_preview.js proj t1 t2 …` -> `preview/f_<t>.png`; read times from `timeline.json`). Fill a defect list: text cut off / overlapping, props over the hero, empty or static first frame, dead stretch (>= 2.5 s with nothing moving), caption zone collision, wrong crop, missing depth layers.
3. **Compare to the bar** (all must hold):
   - hook moves on frame 1; every card adds or moves something; longest still stretch < 2.5 s
   - characters come from `ppl()` (shaded, blinking, arms/shoes), sets from `ROOM.*`/`floor()`+props (>= 6 props, no empty wall, floor with perspective); no flat boxes or stick figures
   - >= 4 depth layers + parallax + ground shadow + camera move in each scene
   - hero animates (bob/blink/reaction); impacts use shake + burst + flash + cue on the same frame
   - cues: <= 8 per 10 s, <= 3 swooshes, varied, each on a visible event, none late
   - captions: <= 2-3 lines, keywords highlighted, <= ~20 chars/s, inside safe zone
   - sound: voice > music > SFX; music 8-20 dB under voice; peak < -0.3 dB
   - ending is a question that continues line 1; loop on
   - smooth: `frame_cost.js` OK (median <= 60 ms), no `shadowBlur`, no per-frame full-screen overlays
4. **Fix** in `scenes.js` / `cards.json` / `cues.json` / `config.json` (fix guide below), rebuild, re-measure. Max 3 loops; each loop must change something measurable.
5. **Facts**: re-read every claim against the sources from the research step; anything unsourced -> hedge or cut. If new facts are needed -> `web_search` again (rule 1).
6. **Report** (Thai, short): measured numbers before -> after, defects fixed, WARNs accepted and why, and the human checklist (hear the audio, word sync, emoji, real-browser MP4 save, phone full-screen). Never say "tested" for what was not run.

## Fix guide
| Finding | Fix |
|---|---|
| frozen picture | `cam()` move, moving elements, new element each card |
| hook static | punch-in / tear / stamp on frame 1, title in with `eb` |
| cues dense or repetitive | drop decorative cues, vary types, <= 3 swooshes |
| music too loud/quiet | `config.mix.music_volume` 0.4-0.9, `duck_ratio` 3-8 |
| captions too long | add `\n`, split card, shorten |
| dead canvas / Pango warning | no `g.scale(0…)`, guard NaN, clamp font >= 1 |
| heavy frames (frame_cost) | remove shadows/blur, wrap static sets in `layer()`, fewer shapes in the slowest scene, cut confetti/dust counts |
| flat/blobby characters, bare walls, plain floor | replace with `ppl()` + `ROOM.*` or `floor()` + props (`references/rig.md`) |
| weak ending | rewrite last card as a question continuing line 1 |

## What tools cannot measure
Hearing audio, word-level sync, emoji rendering, real-browser playback and MP4 export, platform UI overlap, truth of facts. Always list them as the user's checklist.
