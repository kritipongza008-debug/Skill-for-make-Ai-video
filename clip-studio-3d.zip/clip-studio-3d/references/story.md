# STORY mode

## Steps
1. Facts? -> `web_search` first (rule 1). Note sources + what you hedged.
2. Write the best script (below). Assume Thai TikTok/Reels viewers if unstated.
3. Reply with the **hand-off** (format at the bottom). Do not build visuals yet; the user needs to make the voice first.

## Story craft (use as a checklist, not a lecture)
- One idea per clip. Hook in line 1 (first 2-3 s): a question with a guessable answer, a constraint ("คุณมีเวลา 1 นาที"), a pattern break, or a contradiction. No greeting, no "วันนี้เราจะมาพูดถึง".
- Spine: a visible counter/clock/stakes that drives the beats. Something changes on screen every 2-4 s -> write beats that can be *drawn*, not just said.
- Twist or payoff in the last third; **last line is a question that grammatically continues line 1** (loop).
- Contrast is the joke: deadpan voice + absurd content. Kids: 8-12 word sentences, one interactive pause ("ตะโกนบอกเลย!"), warm, no scary.
- Formats that work: ถ้าเกิดเป็น X (deadpan) / ที่มาของ… / ทำไมห้าม… (beliefs, hedged) / A vs B / countdown challenge / ทายเงา (kids) / นิทาน 1 นาที (kids) / ที่มาของของธรรมดา.

## Writing for TTS (Thai)
- Plain spoken Thai, sentences <= 12 words, no abbreviations; years as spoken ("ปี 2398"). Hedge legends.
- Length: ~13-14 chars/s. 40 s ~ 550 chars, 60 s ~ 800, 90 s ~ 1,200 (no spaces) + ~10% pauses.
- Pauses become caption cards: **space** between phrases, **comma/full stop** for a longer pause, "?" for the longest. Phrase = 1.5-4 s (10-40 chars).
- Respell mis-read words in the script ("regenerate with a respelled word"), never edit audio.
- Voice direction by genre: deadpan = calm, slightly slow, never laughs; history = warm, curious; kids = bright, varied pitch; challenge = fast, rising.

## Split-voice mode (user asked for it)
- Cast table: tag, who, personality, voice direction (age/pitch/pace) so the user can pick a matching ElevenLabs voice.
- One turn per line, prefixed `[A] [B]…`, in speaking order. Keep each turn short; label narrator as its own tag if present.
- Also give a **numbered turn list** (`01_A`, `02_B`, …) for per-line generation, and the same text as one block for Text-to-Dialogue (see `voices.md`). Same words in both; never rewrite between versions.

## Hand-off format (Thai, compact)
1. Title + hook line
2. **บทพูด** — one copy-paste block (split mode: tagged lines, then cast table)
3. Voice direction (1 line; split mode: in the cast table) + model tip
4. ElevenLabs link(s) + 3-step how-to (from `voices.md`)
5. Fact notes + sources (only if researched) and what was hedged
6. Next step: "เจนเสียงเสร็จส่ง mp3 มา (split: ส่งทุกไฟล์เรียงเลข หรือไฟล์เดียวจาก Dialogue)"
