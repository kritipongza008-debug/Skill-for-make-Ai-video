# Polish guide — making scenes look professional (read before writing scenes.js)

Lessons from rebuilding the T-rex clip (v1 flat → v2 layered). v1 passed the audit but looked like clip-art on a gradient. The audit measures motion, not beauty, so apply this checklist by hand.

## 1. Every scene has 4+ depth layers
sky/gradient → glow or light source → 2 parallax silhouettes (`hills(base,amp,fq,col,drift,t)`; far layer drift ~6, near ~16–60) → ground → hero → foreground accent (grass `wl`, ferns) → particles (`dust`, fireflies) → vignette/grain (automatic).
A hero standing on a flat gradient is the #1 amateur look. Always add a `groundShadow` under anything standing.

## 2. Nothing is ever still
- Ambient: `drift(t)` handheld sway at the top of every scene, `clouds`, `dust`, bobbing props (`Math.sin(t*3)*12`), swaying plants.
- Character: breathing/bob, tail sway, blink, walk cycle when it travels (hills scroll the opposite way), eye `look` and `brow` to show emotion. A character that reacts (sweat, hop, jaw open, brow) is worth more than a new background.
- Rule: if two consecutive frames 1 s apart look identical outside the caption, the scene is dead.

## 3. Make every spoken idea a *visual metaphor*, not a label
Bad: chip saying the number. Good: object that proves it.
- weight comparison → balance scale tilting, then levelling (`≈`) — not two icons side by side
- "grows fast" → ghost silhouettes of earlier sizes behind the hero + floating "+2 กก." chips
- "can't reach" → tiny limb with pulsing ring, dashed reach gap, far-away glowing object, sweat, X
- "danger/looming" → giant foot stamps in, ground shadow grows first, screen shake, dust burst, hero hops
- time/lifespan → progress bar with the character walking along it + clock hand speeding up
- numbers → `rollNum` counting up inside the scene, with units, one big number per scene

## 4. Impact = shake + burst + flash + sound, same frame
`shk(t,t0,amp,dur)` (call after `g.save()` at scene start), `burst(t,t0,x,y,col)`, `flash(t,t0)`, stamp (`stampAt`). Pair each with a baked cue (`stamp`, `thump`). Max 1–2 impacts per 10 s; use bigger amplitude only for the hero beat.
Start every scene with `flash(t,CD(k),.4,.16)` — a quick bright pop makes cuts feel edited instead of faded.

## 5. Composition
- Hero at the lower third (feet y 900–960), headroom for number/title in y 250–450, props to the side, caption zone (y ≥ 800 gradient) empty. Check the sheet: nothing important under the caption.
- Keep props from overlapping the hero's extents: rex-like heroes are ~540 px wide at scale 1 — plan columns (hero x 230, prop column x 575).
- Camera: use `cam()` in every scene but vary it (push-in, pull-out, pan, punch-in then settle). Keep the zoom centre near the subject; a centre far from the subject slides objects off screen.
- Scene change every 2–4 s; first scene opens already moving (pop-in starts at scale ≥ .5, never an empty first frame).

## 6. Colour & type
One palette per scene (sky, mid, ground, accent) and a recurring accent colour across the clip (here: yellow `#ffd23a` for numbers/age chip, red for danger). Dark scene for danger/bite, warm for growth, cool for size comparison, purple dusk for ending. Big numbers: 140–150 px, 700 weight, thick dark outline. Chips and the age/clock overlay use dark pill + accent border.

## 7. Character recipe (rex-style paper-cut)
Far leg, tail, body + stripes + belly highlight, near leg, neck, head with upper/lower jaw, eye with blink and brow, tiny arm last. Legs rotate from the hip (`ph=t*8`); shadows via `pap(...,col,shadow)`. The same function is reused at scale .17 (icon) to 2.2 (close-up) — build characters as parametrised functions, not one-off drawings.

## 8. Pitfalls found
- `window` does not exist in the headless preview: never reference it in scenes.js.
- Anything that scales to 0 breaks node-canvas: use `eb` (floor .001) or `.0001+…`.
- Camera zoom + props placed near the screen edge → cropped objects; check frames near each scene's *end*, not just the start.
- Crossfade (0.4 s) overlays two scenes: a frame sampled just after a cut will look doubled; sample mid-scene when judging layout (`node render_preview.js proj t1 t2 …`).

## 9. Review loop (always)
1) full sheet, 2) pick the weakest 3 scenes, render frames near their end/impact times, 3) fix overlaps/cropping, 4) re-render, 5) audit. Do not publish after only the first sheet.
