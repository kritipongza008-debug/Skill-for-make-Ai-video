#!/usr/bin/env python3
"""Scaffold a project. Usage: new_project.py <dir> [--script script.txt] [--title "ชื่อคลิป"]
Single voice: plain text. Split voices: one turn per line, prefixed [A] [B] [C]... (speaker tags).
Creates config.json, cards.json (auto-split: REVIEW IT), speakers.json (split only), cues.json, scenes.js."""
import sys,os,json,re,shutil
HERE=os.path.dirname(os.path.abspath(__file__));ROOT=os.path.dirname(HERE)
P=sys.argv[1];os.makedirs(P,exist_ok=True);a=sys.argv[2:]
title=a[a.index('--title')+1] if '--title' in a else 'วิดีโอสั้น'
cfg={'title':title,'file':'video','capY':960,'capSize':54,'loop':True,'music':{'preset':'warm','bpm':84,'level':1},'mix':{'music_volume':.6,'duck_ratio':4,'sfx_volume':.9},'gap_long':.24,'gap_short':.13,'favicon':'🎬'}
COL=['#ffffff','#ffd23a','#7fe3ff','#ffb3d9','#b6f5a8']
def split(txt):
    groups=[g for g in re.split(r'\s+',txt.strip()) if g];cards=[];cur=''
    for g in groups:
        if cur and len((cur+' '+g).replace(' ',''))>26:cards.append(cur);cur=g
        else:cur=(cur+' '+g).strip()
        if g.endswith('?') or g.endswith('!'):cards.append(cur);cur=''
    if cur:cards.append(cur)
    def brk(c):
        if len(c.replace(' ',''))<=18 or ' ' not in c:return c
        sp=[i for i,ch in enumerate(c) if ch==' '];m=len(c)/2;b=min(sp,key=lambda i:abs(i-m));return c[:b]+'\n'+c[b+1:]
    return [brk(c) for c in cards]
cards=['คำเปิด','เนื้อหาตอนกลาง','จุดสำคัญ','คำถามปิด'];spk=None
if '--script' in a:
    txt=open(a[a.index('--script')+1],encoding='utf-8').read().strip()
    tagged=re.findall(r'^\[(\w+)\]\s*(.+)$',txt,re.M)
    if tagged:
        cards=[];spk=[];ids=[]
        for t,line in tagged:
            if t not in ids:ids.append(t)
            c=split(line);cards+=c;spk+=[t]*len(c)
        cfg['speakers']=[{'id':t,'name':t,'color':COL[i%len(COL)]} for i,t in enumerate(ids)]
    else:cards=split(txt)
json.dump(cfg,open(f'{P}/config.json','w'),ensure_ascii=False,indent=1)
json.dump(cards,open(f'{P}/cards.json','w'),ensure_ascii=False,indent=1)
if spk:json.dump(spk,open(f'{P}/speakers.json','w'),ensure_ascii=False)
if not os.path.exists(f'{P}/cues.json'):open(f'{P}/cues.json','w').write('[]')
shutil.copy(f'{ROOT}/assets/starter_scenes.js',f'{P}/scenes.js')
print(f'project ready in {P}: {len(cards)} cards'+(f', speakers {[s["id"] for s in cfg["speakers"]]}' if spk else '')+'. Review cards.json (+speakers.json), then add voice.mp3.')
