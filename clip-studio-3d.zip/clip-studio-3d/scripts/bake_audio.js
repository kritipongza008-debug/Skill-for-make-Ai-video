#!/usr/bin/env node
// Render sound effects + a music bed offline (no external audio files needed).
// Usage: node bake_audio.js <project_dir> | node bake_audio.js --list
// Reads: timeline.json, cues.json  [[cardIndex, offsetSeconds, 'type', param?], ...], config.json (music: {preset,bpm})
// Writes: sfx.wav, music.wav (mono 44.1k)
const req=require('./_req'),fs=require('fs'),path=require('path');
const {OfflineAudioContext}=req('node-web-audio-api');
const SR=44100;
const TYPES={
 // paper / UI
 rustle:'paper rustle (hook, reveal)',page:'page flip',swoosh:'soft whoosh (use sparingly, <=3 per clip)',whooshd:'downward whoosh',pop:'pop (param=freq 400-900)',blip:'rising blip (param=freq 400-900)',tick:'clock tick',ping:'single high ping',
 // impacts
 stamp:'stamp thud (param=freq 80-210)',thump:'low thump',bump:'double bump',gavel:'gavel knock',dong:'low bell, long decay',
 // reveals / success
 chime:'chime (param=[freqs])',sparkle:'rising sparkle',fan:'little fanfare',ding:'ding',coins:'coins',
 // tension / warning
 push:'rising pressure (2.4 s)',horn:'ship horn',creak:'creak',sting:'dissonant sting',buzz:'low buzz',alarm:'alarm beeps',rise:'riser (1 s)',
 // materials
 tear:'paper tear (param=brightness 2200-3400)',snip:'scissors',splash:'water splash',bubbles:'bubbles',gulp:'gulp',puff:'smoke puff',clink:'metal clink'};
if(process.argv[2]==='--list'){for(const k in TYPES)console.log(k.padEnd(9),TYPES[k]);process.exit(0)}
const P=process.argv[2];if(!P){console.error('usage: bake_audio.js <project_dir>');process.exit(1)}
const TL=JSON.parse(fs.readFileSync(path.join(P,'timeline.json'))),CUES=JSON.parse(fs.readFileSync(path.join(P,'cues.json')));
const CFG=fs.existsSync(path.join(P,'config.json'))?JSON.parse(fs.readFileSync(path.join(P,'config.json'))):{};
const MUS=Object.assign({preset:'warm',bpm:84,level:1},CFG.music||{}),DUR=TL.dur+.6;
const PRESETS={ // chords (Hz) + bass roots
 warm:{ch:[[261.6,329.6,392],[220,261.6,329.6],[174.6,220,261.6],[196,246.9,293.7]],root:[130.8,110,87.3,98]},
 mystery:{ch:[[220,261.6,329.6],[174.6,220,261.6],[261.6,329.6,392],[196,246.9,293.7]],root:[110,87.3,130.8,98]},
 bright:{ch:[[392,493.9,587.3],[329.6,392,493.9],[261.6,329.6,392],[293.7,370,440]],root:[196,164.8,130.8,146.8]}};
async function render(len,fn){const c=new OfflineAudioContext(1,Math.ceil(SR*len),SR);fn(c);return (await c.startRendering()).getChannelData(0)}
function wav(d,name){const n=d.length,w=Buffer.alloc(44+n*2);w.write('RIFF',0);w.writeUInt32LE(36+n*2,4);w.write('WAVEfmt ',8);w.writeUInt32LE(16,16);w.writeUInt16LE(1,20);w.writeUInt16LE(1,22);w.writeUInt32LE(SR,24);w.writeUInt32LE(SR*2,28);w.writeUInt16LE(2,32);w.writeUInt16LE(16,34);w.write('data',36);w.writeUInt32LE(n*2,40);for(let i=0;i<n;i++)w.writeInt16LE(Math.max(-32768,Math.min(32767,Math.round(d[i]*32767))),44+i*2);fs.writeFileSync(path.join(P,name),w)}
function lib(c,out){const nb=c.createBuffer(1,SR*2,SR),nd=nb.getChannelData(0);for(let i=0;i<nd.length;i++)nd[i]=Math.random()*2-1;
 const env=(n,t,a,d,pk)=>{n.gain.setValueAtTime(.0001,t);n.gain.linearRampToValueAtTime(pk,t+a);n.gain.exponentialRampToValueAtTime(.0001,t+a+d)};
 const noise=(t,dur,type,f0,f1,q,pk,a=.02)=>{const s=c.createBufferSource();s.buffer=nb;const f=c.createBiquadFilter();f.type=type;f.Q.value=q;f.frequency.setValueAtTime(f0,t);f.frequency.exponentialRampToValueAtTime(f1,t+dur);const e=c.createGain();env(e,t,Math.min(a,dur*.8),dur-Math.min(a,dur*.8),pk);s.connect(f);f.connect(e);e.connect(out);s.start(t);s.stop(t+dur+.05)};
 const tone=(t,f0,f1,dur,pk,ty='sine',a=.005)=>{const o=c.createOscillator();o.type=ty;o.frequency.setValueAtTime(f0,t);o.frequency.exponentialRampToValueAtTime(f1,t+dur);const e=c.createGain();env(e,t,Math.min(a,dur*.8),dur-Math.min(a,dur*.8),pk);o.connect(e);e.connect(out);o.start(t);o.stop(t+dur+.05)};
 return{rustle:t=>{for(let i=0;i<5;i++)noise(t+i*.07,.14,'bandpass',2500+i*500,4500,.6,.9,.01)},
 page:t=>{noise(t,.22,'bandpass',1800,5200,.8,.7,.03);noise(t+.12,.16,'highpass',3000,6000,.8,.5,.01)},
 swoosh:t=>noise(t,.5,'bandpass',500,3000,1.0,.7,.18),whooshd:t=>noise(t,.45,'bandpass',3200,300,1.2,.8,.05),
 pop:(t,f=600)=>tone(t,f*.7,f*1.4,.14,.8,'sine',.003),blip:(t,f=600)=>{tone(t,f,f*1.5,.12,.6,'triangle',.003);tone(t+.06,f*1.5,f*1.5,.2,.3,'sine',.003)},
 tick:t=>tone(t,1200,1000,.05,.4,'square',.001),ping:t=>tone(t,1400,1400,.7,.35,'sine',.004),
 stamp:(t,f=150)=>{tone(t,f,f*.35,.28,1.1,'sine',.003);noise(t,.08,'lowpass',1200,200,.7,.7,.002)},
 thump:t=>{tone(t,120,35,.5,1,'sine',.004);noise(t,.2,'lowpass',500,80,.6,.6,.004)},bump:t=>{tone(t,110,45,.4,1,'sine',.004);tone(t+.12,90,40,.35,.6,'sine',.004)},
 gavel:t=>{tone(t,420,160,.12,.9,'square',.001);noise(t,.06,'highpass',2000,5000,.8,.8,.001);tone(t+.26,420,160,.12,.7,'square',.001)},
 dong:t=>[130,260,390,520].forEach((f,i)=>tone(t,f,f*.99,2.4-i*.4,.8/(i+1),'sine',.006)),
 chime:(t,fs=[660,990])=>fs.forEach((f,i)=>tone(t+i*.09,f,f,1.1-i*.15,.45/(i+1),'sine',.004)),
 sparkle:t=>{for(let i=0;i<7;i++)tone(t+i*.07,1500+i*260,1500+i*260,.25,.22,'sine',.003)},
 fan:t=>{[523,659,784,1047].forEach((f,i)=>tone(t+i*.12,f,f,.9,.45,'triangle',.01));[262,392].forEach(f=>tone(t,f,f,1.2,.35,'sawtooth',.02))},
 ding:t=>[880,1320,1760].forEach((f,i)=>tone(t,f,f,.9-i*.2,.4/(i+1),'sine',.004)),
 coins:t=>{for(let i=0;i<5;i++)tone(t+i*.07,2400+i*180,2300+i*180,.28,.3,'sine',.002)},
 push:t=>{noise(t,2.4,'bandpass',200,900,1.5,.35,1.2);tone(t,80,140,2.4,.3,'sawtooth',1.2)},
 horn:t=>{tone(t,98,92,1.6,.6,'sawtooth',.25);tone(t,147,140,1.6,.4,'sawtooth',.25)},
 creak:t=>{tone(t,180,260,.9,.3,'sawtooth',.2);tone(t+.3,240,170,.9,.25,'sawtooth',.2)},
 sting:t=>{tone(t,311,311,.5,.4,'triangle',.01);tone(t,330,330,.5,.4,'triangle',.01);tone(t,466,466,.5,.25,'triangle',.01)},
 buzz:t=>tone(t,150,125,.45,.5,'sawtooth',.02),alarm:t=>{for(let i=0;i<4;i++)tone(t+i*.16,880,880,.1,.5,'square',.005)},
 rise:t=>{noise(t,.9,'bandpass',400,5000,2,.6,.3);tone(t,220,880,.9,.25,'sawtooth',.2)},
 tear:(t,f=2600)=>{for(let i=0;i<7;i++)noise(t+i*.07,.1,'highpass',f+i*250,f*2,.8,.6-.05*i,.004)},
 snip:t=>{noise(t,.08,'highpass',4000,7000,.9,.9,.002);tone(t,1800,1200,.06,.2,'square',.002)},
 splash:t=>{noise(t,.6,'lowpass',3000,300,.7,.9,.01);tone(t,300,120,.3,.4,'sine',.004)},
 bubbles:t=>{for(let i=0;i<6;i++)tone(t+i*.09,300+i*90+Math.random()*60,500+i*130,.12,.35,'sine',.004)},
 gulp:t=>{tone(t,220,90,.22,.9,'sine',.005);tone(t+.18,200,70,.28,.7,'sine',.005);noise(t,.2,'lowpass',600,120,.8,.4,.01)},
 puff:t=>noise(t,.6,'lowpass',2500,200,.7,.9,.03),clink:t=>[1760,2349,2960].forEach((f,i)=>tone(t+i*.05,f,f*.99,.35,.3,'sine',.002))}}
async function music(){const pre=PRESETS[MUS.preset]||PRESETS.warm;return render(DUR,c=>{const out=c.createGain();out.gain.value=.5*MUS.level;const lp=c.createBiquadFilter();lp.type='lowpass';lp.frequency.value=1500;const fade=c.createGain();fade.gain.setValueAtTime(1,0);fade.gain.setValueAtTime(1,Math.max(0,DUR-3));fade.gain.linearRampToValueAtTime(0,DUR);out.connect(lp);lp.connect(fade);fade.connect(c.destination);
 const beat=60/MUS.bpm;for(let b=0,k=0;b*beat<DUR;b+=4,k++){const t=b*beat,i=k%4;pre.ch[i].forEach(f=>[-3,3].forEach(dt=>{const o=c.createOscillator();o.type='triangle';o.frequency.value=f;o.detune.value=dt;const e=c.createGain();e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(.09,t+1.3);e.gain.setValueAtTime(.09,t+4*beat-1.2);e.gain.linearRampToValueAtTime(.0001,t+4*beat+.4);o.connect(e);e.connect(out);o.start(t);o.stop(t+4*beat+.5)}));
  const o=c.createOscillator();o.type='sine';o.frequency.value=pre.root[i];const e=c.createGain();e.gain.setValueAtTime(.0001,t);e.gain.linearRampToValueAtTime(.16,t+.5);e.gain.setValueAtTime(.16,t+4*beat-.6);e.gain.linearRampToValueAtTime(.0001,t+4*beat+.3);o.connect(e);e.connect(out);o.start(t);o.stop(t+4*beat+.4);
  for(let n=0;n<8;n++){const f=pre.ch[i][[0,1,2,1,0,2,1,2][n]]*2,tt=t+n*beat/2,o2=c.createOscillator();o2.type='sine';o2.frequency.value=f;const e2=c.createGain();e2.gain.setValueAtTime(.0001,tt);e2.gain.linearRampToValueAtTime(.07,tt+.01);e2.gain.exponentialRampToValueAtTime(.0001,tt+.7);o2.connect(e2);e2.connect(out);o2.start(tt);o2.stop(tt+.75)}}})}
(async()=>{const bad=CUES.filter(q=>!TYPES[q[2]]||!TL.cards[q[0]]);if(bad.length){console.error('bad cues (unknown type or card index):',JSON.stringify(bad));process.exit(1)}
 const sfx=await render(DUR,c=>{const out=c.createGain();out.gain.value=.4;out.connect(c.destination);const L=lib(c,out);CUES.forEach(q=>L[q[2]](TL.cards[q[0]].t0+q[1],q[3]))});
 wav(sfx,'sfx.wav');wav(await music(),'music.wav');console.log('baked',CUES.length,'cues, music preset',MUS.preset,'@',MUS.bpm,'bpm, length',DUR.toFixed(1)+'s')})();
