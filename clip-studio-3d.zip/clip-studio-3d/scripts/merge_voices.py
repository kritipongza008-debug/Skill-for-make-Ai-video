#!/usr/bin/env python3
"""Join several voice files (one per turn/voice) into proj/voice.mp3, in the order given.
Usage: merge_voices.py <project_dir> 01_A.mp3 02_B.mp3 ...   (use zero-padded numbers so the shell sorts them)
A short gap is inserted between files; tighten_align.py later trims/normalises pauses."""
import sys,os,subprocess
P=sys.argv[1].rstrip('/');fs=sys.argv[2:]
if len(fs)<2:sys.exit('need at least 2 files')
ins=' '.join(f'-i "{f}"' for f in fs);parts=[];order=''
for i in range(len(fs)):
    parts.append(f'[{i}:a]aformat=sample_rates=44100:channel_layouts=mono[a{i}]');order+=f'[a{i}]'
    if i<len(fs)-1:parts.append(f'anullsrc=r=44100:cl=mono,atrim=0:0.15,asetpts=PTS-STARTPTS[g{i}]');order+=f'[g{i}]'
fc=';'.join(parts)+f';{order}concat=n={2*len(fs)-1}:v=0:a=1[o]'
open(f'{P}/fc_merge.txt','w').write(fc)
r=subprocess.run(f'ffmpeg -y -loglevel error {ins} -filter_complex_script {P}/fc_merge.txt -map "[o]" -b:a 192k {P}/voice.mp3',shell=True,capture_output=True,text=True)
if r.returncode:sys.exit(r.stderr)
d=subprocess.run(f'ffprobe -v error -show_entries format=duration -of csv=p=0 {P}/voice.mp3',shell=True,capture_output=True,text=True).stdout.strip()
os.remove(f'{P}/fc_merge.txt');print(f'wrote {P}/voice.mp3 ({float(d):.1f}s) from {len(fs)} files')
