#!/usr/bin/env python3
"""Assemble the self-contained HTML video page. Usage: build_video.py <project_dir> [--no-audio]
Needs: timeline.json, scenes.js, config.json, and (unless --no-audio) mixed.mp3 + voice_t.mp3.
Writes <project>/out/video.html and prints size + a syntax check."""
import sys,os,json,base64,subprocess
HERE=os.path.dirname(os.path.abspath(__file__));ROOT=os.path.dirname(HERE)
P=sys.argv[1].rstrip('/');noaudio='--no-audio' in sys.argv
cfg=json.load(open(f'{P}/config.json')) if os.path.exists(f'{P}/config.json') else {}
tl=json.load(open(f'{P}/timeline.json'));tl={'dur':tl['dur'],'cards':tl['cards']}
if os.path.exists(f'{P}/speakers.json'):
    sp=json.load(open(f'{P}/speakers.json'))
    for i,c in enumerate(tl['cards']):
        if i<len(sp):c['spk']=sp[i]
tpl=open(f'{ROOT}/assets/player_template.html').read()
lib=open(f'{ROOT}/assets/lib/core.js').read()+'\n'+open(f'{ROOT}/assets/lib/rig.js').read();scenes=open(f'{P}/scenes.js').read()
b64=lambda p:base64.b64encode(open(p,'rb').read()).decode()
if noaudio:
    # a REAL silent mp3 (the player's clock is the audio element; an invalid stub never plays or ends -> clip freezes at frame 0)
    import subprocess;sil=f'{P}/out/_silent.mp3';os.makedirs(f'{P}/out',exist_ok=True)
    subprocess.run(['ffmpeg','-y','-loglevel','error','-f','lavfi','-i','anullsrc=r=22050:cl=mono','-t',f"{tl['dur']+0.6:.2f}",'-b:a','32k',sil],check=True)
    a=a0=b64(sil);os.remove(sil)
else:a=b64(f'{P}/mixed.mp3');a0=b64(f'{P}/voice_t.mp3')
out=tpl.replace('__TITLE__',cfg.get('title','วิดีโอสั้น')).replace('__AUDIO0__',a0).replace('__AUDIO__',a).replace('__CONFIG__',json.dumps(cfg,ensure_ascii=False)).replace('__TIMELINE__',json.dumps(tl,ensure_ascii=False)).replace('/*@@LIB@@*/',lib).replace('/*@@SCENES@@*/',scenes)
os.makedirs(f'{P}/out',exist_ok=True);dest=f'{P}/out/video{"_noaudio" if noaudio else ""}.html';open(dest,'w').write(out)
size=os.path.getsize(dest)/1e6;print(f'wrote {dest} ({size:.1f} MB)')
if size>15:print('WARNING: published pages must stay under 16 MB; shorten the audio or lower the bitrate')
js="const s=require('fs').readFileSync(process.argv[1],'utf8');const m=s.match(/<script>([\\s\\S]*)<\\/script>/)[1].replace(/const AUDIO=.*\\n/,'const AUDIO=\"\",AUDIO0=\"\";\\n');try{new Function(m);console.log('syntax ok')}catch(e){console.log('SYNTAX ERROR: '+e.message);process.exit(1)}"
r=subprocess.run(['node','-e',js,dest],capture_output=True,text=True);print(r.stdout.strip(),r.stderr.strip())
sys.exit(r.returncode)
