#!/usr/bin/env bash
# One-time setup: installs the node packages the scripts need into ~/.svs (outside the skill folder).
set -e
command -v ffmpeg >/dev/null || { echo "ffmpeg is required"; exit 1; }
command -v node >/dev/null || { echo "node is required"; exit 1; }
python3 -c "import PIL" 2>/dev/null || pip install pillow --break-system-packages -q
mkdir -p ~/.svs && cd ~/.svs
[ -f package.json ] || echo '{"name":"svs-deps","version":"1.0.0","private":true}' > package.json
npm ls canvas node-web-audio-api >/dev/null 2>&1 || npm i canvas node-web-audio-api 2>&1 | tail -2
echo "setup ok (node modules in ~/.svs/node_modules)"
