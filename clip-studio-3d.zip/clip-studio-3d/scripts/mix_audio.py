#!/usr/bin/env python3
"""Mix voice + music (ducked under voice) + SFX. Usage: mix_audio.py <project_dir>
Reads voice_t.wav, music.wav, sfx.wav  Writes mixed.mp3 (+ voice_t.mp3 for 'effects off') and prints levels."""
import sys,os,json,re,subprocess
def sh(c):return subprocess.run(c,shell=True,capture_output=True,text=True)
P=sys.argv[1].rstrip('/');os.chdir(P)
cfg=json.load(open('config.json')) if os.path.exists('config.json') else {}
m=cfg.get('mix',{});mv,ratio,thr,sv=m.get('music_volume',.6),m.get('duck_ratio',4),m.get('duck_threshold',.03),m.get('sfx_volume',.9)
fc=f"[0:a]asplit=2[v][k];[1:a]volume={mv}[m0];[m0][k]sidechaincompress=threshold={thr}:ratio={ratio}:attack=15:release=400[md];[2:a]volume={sv}[s];[v][md][s]amix=inputs=3:duration=first:normalize=0,alimiter=limit=0.95"
r=sh(f'ffmpeg -y -loglevel error -i voice_t.wav -i music.wav -i sfx.wav -filter_complex "{fc}" -b:a 128k mixed.mp3');print(r.stderr)
sh('ffmpeg -y -loglevel error -i voice_t.wav -b:a 128k voice_t.mp3')
def lvl(f,extra=''):
    o=sh(f'ffmpeg -i {f} {extra} -af volumedetect -f null - 2>&1').stdout
    mean=re.search(r'mean_volume: (-?[0-9.]+)',o);mx=re.search(r'max_volume: (-?[0-9.]+)',o)
    return (float(mean.group(1)) if mean else None,float(mx.group(1)) if mx else None)
# music level as heard under the voice
sh(f'ffmpeg -y -loglevel error -i voice_t.wav -i music.wav -filter_complex "[0:a]asplit=2[v][k];[v]anullsink;[1:a]volume={mv}[m0];[m0][k]sidechaincompress=threshold={thr}:ratio={ratio}:attack=15:release=400[md]" -map "[md]" md_tmp.wav')
res={'voice':lvl('voice_t.wav'),'sfx':lvl('sfx.wav'),'music_ducked':lvl('md_tmp.wav'),'mixed':lvl('mixed.mp3')}
os.remove('md_tmp.wav') if os.path.exists('md_tmp.wav') else None
json.dump(res,open('levels.json','w'));print(json.dumps(res))
