#!/usr/bin/env python3
"""Self-check for a built project. Usage: audit_video.py <project_dir> [--no-render]
Measures what a machine CAN measure (pacing, motion, caption load, SFX density/variety, levels, hook/loop heuristics,
renderer faults) and prints what only a human can check. Writes <project>/audit.md.
Status: OK = passes the heuristic, WARN = look at it, FAIL = fix before delivering, INFO = FYI."""
import sys,os,json,re,subprocess,statistics as S
HERE=os.path.dirname(os.path.abspath(__file__))
P=sys.argv[1].rstrip('/');norender='--no-render' in sys.argv
tl=json.load(open(f'{P}/timeline.json'));cards=tl['cards'];dur=tl['dur'];stats=tl.get('stats',{})
cfg=json.load(open(f'{P}/config.json')) if os.path.exists(f'{P}/config.json') else {}
cues=json.load(open(f'{P}/cues.json')) if os.path.exists(f'{P}/cues.json') else []
lev=json.load(open(f'{P}/levels.json')) if os.path.exists(f'{P}/levels.json') else None
R=[]
def add(area,status,msg,fix=''):R.append((area,status,msg,fix))
# ---- renderer sweep (motion / faults)
sw=None
if not norender:
    r=subprocess.run(['node',f'{HERE}/render_preview.js',P,'--sweep','0.25'],capture_output=True,text=True)
    if 'Pango-CRITICAL' in r.stderr:add('Renderer','FAIL','Pango-CRITICAL warnings (negative/zero font size somewhere).','Search scenes.js for tx(...) calls whose size can reach 0 or go negative; clamp with Math.max(1,size).')
    if r.returncode and 'Missing npm' in r.stderr:add('Renderer','FAIL','node modules missing','bash scripts/setup.sh')
    elif r.returncode:add('Renderer','FAIL','sweep crashed: '+r.stderr.strip()[-300:],'Fix the exception shown, rebuild, rerun.')
    if os.path.exists(f'{P}/preview/sweep.json'):sw=json.load(open(f'{P}/preview/sweep.json'))
if sw:
    d=sw['diffs'];step=sw['step'];eps=.15
    # static holds
    best=0;cur=0;at=0
    for i,x in enumerate(d):
        if x<eps:
            cur+=1
            if cur>best:best=cur;at=i
        else:cur=0
    hold=best*step;start=(at-best+1)*step
    if hold>=4:add('Pacing','FAIL',f'Picture is frozen for {hold:.1f}s (around {start:.1f}s).','Add motion: camera push (cam), moving elements, a new element per caption card.')
    elif hold>=2.5:add('Pacing','WARN',f'Longest frozen stretch {hold:.1f}s (around {start:.1f}s).','Add a visual event at least every ~3 s.')
    else:add('Pacing','OK',f'Longest frozen stretch {hold:.1f}s (<2.5 s).')
    nz=[x for x in d if x>eps];med=S.median(nz) if nz else 0
    cuts=sum(1 for x in d if med and x>max(6,med*4))
    add('Pacing','INFO',f'{cuts} hard visual cuts in {dur:.0f}s (about one per {dur/max(1,cuts):.1f}s); motion median {med:.1f}.')
    h=d[:int(3/step)];hm=sum(h)/max(1,len(h))
    add('Hook','OK' if hm>2 else 'WARN',f'Average motion in the first 3 s = {hm:.1f}'+('' if hm>2 else ' (looks static)'),'Open with movement/impact in frame 1: punch-in, tear, stamp, countdown.')
    # dead canvas: long exact-zero runs while captions change
    zero=0;zmax=0
    for x in d:
        zero=zero+1 if x==0 else 0;zmax=max(zmax,zero)
    if zmax*step>=3:add('Renderer','FAIL',f'{zmax*step:.1f}s of identical frames: canvas may have died (scale(0)/NaN transform).','Use eb() (never 0) for scales; check for NaN in positions; see references/pitfalls.md.')
else:add('Pacing','INFO','Motion sweep skipped (no render).')
# ---- hook text / ending
c0=' '.join(c['text'] for c in cards[:2]).replace('\n','')
hookw=['ทำไม','ถ้า','รู้ไหม','เคย','อะไร','ใคร','อย่า','หยุด','?','ลอง','ความลับ','จริงหรือ']
add('Hook','OK' if any(w in c0 for w in hookw) else 'WARN',f'Opening words: "{c0[:48]}"','Open with a question / bold claim / pattern break in the first 2 s (see references/story-genres.md).')
if cards[0]['t0']>.5:add('Hook','WARN',f'First caption appears at {cards[0]["t0"]}s','Start the voice within 0.3 s of the first frame.')
last=cards[-1]['text'].replace('\n','');cta=['?','คิดว่า','คอมเมนต์','เล่า','ลอง','แท็ก','อะไร','ไหม','ใคร','ไง','หรือ']
add('Ending','OK' if any(w in last for w in cta) else 'WARN',f'Last card: "{last}"','End on a question/CTA, ideally one that grammatically continues into the first line so the loop feels seamless.')
add('Ending','OK' if cfg.get('loop',True) else 'WARN','Loop crossfade '+('on' if cfg.get('loop',True) else 'OFF'),'Set "loop": true in config.json.')
# ---- dead air
pb=stats.get('pause_share_before');pa=stats.get('pause_share_after')
if pb is not None:
    pa=pb if pa is None else pa
    add('Pacing','OK' if pa<.15 else 'WARN',f'Pauses were {pb*100:.0f}% of the raw audio, {pa*100:.0f}% after tightening ({stats.get("orig_dur")}s -> {stats.get("new_dur")}s, saved {stats.get("saved","?")}s).','If still slow: raise the voice speed slightly, or lower gap_long/gap_short in config.json.')
# ---- captions
cps=[];tooquick=[];longline=0;lines3=0
for c in cards:
    t=c['text'].replace('\n','').replace(' ','');d_=max(.1,c['t1']-c['t0']);cps.append(len(t)/d_)
    if len(t)>8 and d_<.8:tooquick.append(c['text'].replace('\n',' '))
    for l in c['text'].split('\n'):
        if len(l.replace(' ',''))>26:longline+=1
    if c['text'].count('\n')>=3:lines3+=1
add('Captions','OK' if max(cps)<20 else 'WARN',f'Reading speed: median {S.median(cps):.1f} chars/s, max {max(cps):.1f}.' ,'Split or shorten cards that flash by (<0.8 s with >8 chars).')
if tooquick:add('Captions','WARN','Very short cards: '+'; '.join(tooquick[:3]),'Merge with neighbouring card.')
if longline:add('Captions','WARN',f'{longline} caption line(s) longer than 26 chars (auto-shrunk to fit).','Insert \\n to break lines at word boundaries.')
capy=cfg.get('capY',960)
add('Captions','OK' if capy<=1000 else 'WARN',f'Caption baseline y={capy}/1280 ({capy/12.8:.0f}% down).','Keep captions above ~80% height so app buttons/username do not cover them (general rule of thumb, verify per platform).')
# ---- sound
if cues:
    n=len(cues);dens=n/(dur/10);types={}
    for q in cues:types[q[2]]=types.get(q[2],0)+1
    top=max(types.items(),key=lambda kv:kv[1])
    add('Sound','OK' if dens<=8 else 'WARN',f'{n} sound cues, {dens:.1f} per 10 s, {len(types)} different types.','Every cue should mark an event the viewer can see; drop decorative ones.')
    add('Sound','OK' if top[1]/n<.3 else 'WARN',f'Most repeated cue: "{top[0]}" x{top[1]} ({top[1]/n*100:.0f}%).','Vary types/pitch; whoosh/swoosh/pop on every cut sounds like a template.')
    sw_=sum(types.get(k,0) for k in('swoosh','whooshd','whoosh'))
    if sw_>3:add('Sound','WARN',f'{sw_} whoosh-type cues (limit ~3).','Use swoosh only for big scene changes.')
    ts=sorted(cards[q[0]]['t0']+q[1] for q in cues);mg=min([b-a for a,b in zip(ts,ts[1:])]+[9])
    if mg<.25:add('Sound','WARN',f'Two cues only {mg:.2f}s apart.','Stagger or remove one; overlapping cues mush on phone speakers.')
    late=[q for q in cues if q[1]>cards[q[0]]['t1']-cards[q[0]]['t0']+.2]
    if late:add('Sound','WARN',f'{len(late)} cue(s) fire after their card has ended (e.g. card {late[0][0]}).','Reduce the offset or attach the cue to the next card.')
else:add('Sound','WARN','No SFX cues (cues.json is empty).','Add 1 cue per visible event; see references/sfx-and-music.md.')
if lev:
    v=lev['voice'][0];m=lev['music_ducked'][0];mx=lev['mixed'][1];sx=lev['sfx'][1]
    if m is not None:add('Sound','OK' if 8<=v-m<=20 else 'WARN',f'Music sits {v-m:.0f} dB under the voice while talking (target 8-20 dB).','Adjust mix.music_volume / duck_ratio in config.json.')
    add('Sound','OK' if mx is not None and mx<-.3 else 'FAIL',f'Mixed peak {mx} dB.' ,'Lower sfx_volume or music_volume (clipping).')
    if sx is not None and sx>-3:add('Sound','WARN',f'SFX peak {sx} dB is loud next to the voice.','Lower mix.sfx_volume.')
else:add('Sound','INFO','levels.json missing: run mix_audio.py to measure levels.')
# ---- claims
add('Facts','INFO','Machine cannot verify facts. Every date/number/claim in the cards must have been searched; uncertain legends must say "เล่ากันว่า / คนเชื่อว่า".','Re-read cards.json against your sources.')
# ---- human checklist
H=['Listen to the final mixed audio once with headphones AND once on a phone speaker (cannot be done by a machine).',
'Play the page and check sync at 3 points (start, middle, end): does the visual event land on the spoken word? Timing is an estimate (no speech recognition).',
'Press "บันทึกเป็น MP4" in a real browser: Chrome/Safari give MP4, Firefox gives WebM. Confirm the file plays with sound.',
'Watch it on a phone at full screen: are captions covered by app buttons? Is any text cut at the edges?',
'Emoji only render in the real browser: check the emoji beside captions look right on your device.',
'Read the facts line by line against sources; remove anything you cannot source.']
icon={'OK':'✅','WARN':'⚠️','FAIL':'❌','INFO':'ℹ️'}
out=['# Audit — '+cfg.get('title','video'),f'duration {dur}s, {len(cards)} cards, {len(cues)} cues','']
for a_ in ['Hook','Pacing','Captions','Sound','Ending','Renderer','Facts']:
    rows=[r for r in R if r[0]==a_]
    if rows:out.append('## '+a_)
    for _,s,m,f in rows:out.append(f'- {icon[s]} **{s}** {m}'+(f'  \n  → {f}' if f and s in('WARN','FAIL') else ''))
out+=['','## Must be checked by a human (not measurable here)']+[f'- [ ] {h}' for h in H]
fails=sum(1 for r in R if r[1]=='FAIL');warns=sum(1 for r in R if r[1]=='WARN')
out.insert(2,f'**Result: {fails} FAIL, {warns} WARN.** '+('Fix FAILs before delivering.' if fails else 'No blocking faults; review WARNs.'))
txt='\n'.join(out);open(f'{P}/audit.md','w').write(txt);print(txt)
