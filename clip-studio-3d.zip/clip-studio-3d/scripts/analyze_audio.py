#!/usr/bin/env python3
"""Analyze a voice-over file: duration, speech segments, pauses, dead-air share.
Usage: analyze_audio.py voice.mp3 [--noise -35] [--min 0.18]   (prints JSON)"""
import subprocess,re,sys,json
def sh(c):return subprocess.run(c,shell=True,capture_output=True,text=True)
def analyze(src,noise=-35,mind=.18):
    dur=float(sh(f'ffprobe -v error -show_entries format=duration -of csv=p=0 "{src}"').stdout)
    o=sh(f'ffmpeg -i "{src}" -af silencedetect=noise={noise}dB:d={mind} -f null - 2>&1').stdout
    ss=[float(x) for x in re.findall(r'silence_start: ([0-9.]+)',o)];se=[float(x) for x in re.findall(r'silence_end: ([0-9.]+)',o)]
    segs=[];cur=0.0
    for a,b in zip(ss,se):
        if a-cur>.15:segs.append([round(cur,3),round(a,3)])
        cur=b
    if dur-cur>.15:segs.append([round(cur,3),round(dur,3)])
    gaps=[round(segs[i+1][0]-segs[i][1],3) for i in range(len(segs)-1)]
    speech=sum(e-s for s,e in segs)
    return {'duration':round(dur,3),'segments':segs,'gaps':gaps,'speech_seconds':round(speech,2),'pause_seconds':round(dur-speech,2),'pause_share':round((dur-speech)/dur,3),'long_gaps_over_0.5s':sum(1 for x in gaps if x>=.5)}
if __name__=='__main__':
    a=sys.argv[1:];noise=-35;mind=.18
    if '--noise' in a:noise=float(a[a.index('--noise')+1])
    if '--min' in a:mind=float(a[a.index('--min')+1])
    print(json.dumps(analyze(a[0],noise,mind),ensure_ascii=False,indent=1))
