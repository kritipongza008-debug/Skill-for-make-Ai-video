#!/usr/bin/env node
// Headless preview of the built page (node-canvas).  No browser needed, but emoji are not drawn (no emoji font).
// Usage: node render_preview.js <project_dir> [t1 t2 ...]        -> preview/f_<t>.png + preview/sheet.png (default: 16 even frames)
//        node render_preview.js <project_dir> --sweep 0.25       -> preview/sweep.json (frame-to-frame motion for audit_video.py)
const req=require('./_req'),fs=require('fs'),path=require('path');
const {createCanvas}=req('canvas');
const P=process.argv[2],args=process.argv.slice(3),sweep=args[0]==='--sweep';
let html=path.join(P,'out/video_noaudio.html');if(!fs.existsSync(html))html=path.join(P,'out/video.html');
const s=fs.readFileSync(html,'utf8');let m=s.match(/<script>([\s\S]*)<\/script>/)[1];
m=m.replace(/const AUDIO=.*\n/,'');m=m.slice(0,m.indexOf('/* ---- player ---- */'));
m=m.replace("let g;const cv=document.getElementById('cv'),st=document.getElementById('st');g=cv.getContext('2d');","let g;const cv=createCanvas(720,1280);g=cv.getContext('2d');");
if(sweep)m=m.replace("const F=","CONFIG.grain=false;const F=");
const Pr=Object.getPrototypeOf(createCanvas(1,1).getContext('2d'));
if(!Pr.roundRect)Pr.roundRect=function(x,y,w,h,r){r=Array.isArray(r)?r[0]:r;r=Math.min(r,w/2,h/2);this.moveTo(x+r,y);this.arcTo(x+w,y,x+w,y+h,r);this.arcTo(x+w,y+h,x,y+h,r);this.arcTo(x,y+h,x,y,r);this.arcTo(x,y,x+w,y,r);this.closePath()};
const doc={createElement:()=>createCanvas(1,1)};
const {draw,cv,DURV}=new Function('createCanvas','document',m+';return {draw,cv,DURV:DUR}')(createCanvas,doc);
fs.mkdirSync(path.join(P,'preview'),{recursive:true});
if(sweep){const step=parseFloat(args[1]||'.25'),sm=createCanvas(90,160),sg=sm.getContext('2d');let prev=null;const out={step,dur:DURV,diffs:[],bright:[]};
 for(let t=0;t<=DURV;t+=step){draw(t);sg.drawImage(cv,0,0,90,160);const d=sg.getImageData(0,0,90,160).data;let sum=0,br=0;const gr=new Float32Array(90*160);for(let i=0;i<gr.length;i++){gr[i]=(d[i*4]+d[i*4+1]+d[i*4+2])/3;br+=gr[i]}if(prev)for(let i=0;i<gr.length;i++)sum+=Math.abs(gr[i]-prev[i]);out.diffs.push(prev?+(sum/gr.length).toFixed(3):0);out.bright.push(+(br/gr.length).toFixed(1));prev=gr}
 fs.writeFileSync(path.join(P,'preview/sweep.json'),JSON.stringify(out));console.log('sweep frames:',out.diffs.length)}
else{let ts=args.map(Number).filter(x=>!isNaN(x));if(!ts.length)ts=[...Array(16)].map((_,i)=>+(i*(DURV-.3)/15).toFixed(1));
 const cols=Math.min(8,ts.length),rows=Math.ceil(ts.length/cols),sh=createCanvas(cols*240,rows*427),sc=sh.getContext('2d');
 ts.forEach((t,i)=>{draw(t);fs.writeFileSync(path.join(P,'preview',`f_${t}.png`),cv.toBuffer('image/png'));sc.drawImage(cv,(i%cols)*240,Math.floor(i/cols)*427,240,427);sc.fillStyle='#fff';sc.font='16px sans-serif';sc.fillText(t+'s',(i%cols)*240+6,Math.floor(i/cols)*427+18)});
 fs.writeFileSync(path.join(P,'preview/sheet.png'),sh.toBuffer('image/png'));console.log('wrote preview/sheet.png with',ts.length,'frames')}
