// Smoothness check: how long one frame takes to draw. Usage: node frame_cost.js <project_dir>
// Uses node-canvas (software). Numbers are for COMPARING versions, not real browser speed.
// Needs out/video_noaudio.html (build_video.py --no-audio). WARN median>60ms, FAIL median>90ms.
const req=require('./_req'),fs=require('fs');const {createCanvas}=req('canvas');
const P=process.argv[2];const f=[P+'/out/video_noaudio.html',P+'/out/video.html'].find(x=>fs.existsSync(x));
if(!f){console.log('build first (build_video.py --no-audio)');process.exit(1)}
let m=fs.readFileSync(f,'utf8').match(/<script>([\s\S]*)<\/script>/)[1];
m=m.replace(/const AUDIO0?=.*\n/g,'');m=m.slice(0,m.indexOf('/* ---- player ---- */'));
m=m.replace("let g;const cv=document.getElementById('cv'),st=document.getElementById('st');g=cv.getContext('2d');","let g;const cv=createCanvas(720,1280);g=cv.getContext('2d');");
const Pr=Object.getPrototypeOf(createCanvas(1,1).getContext('2d'));
if(!Pr.roundRect)Pr.roundRect=function(x,y,w,h,r){r=Array.isArray(r)?r[0]:r;r=Math.min(r,w/2,h/2);this.moveTo(x+r,y);this.arcTo(x+w,y,x+w,y+h,r);this.arcTo(x+w,y+h,x,y+h,r);this.arcTo(x,y,x+w,y,r);this.closePath()};
const doc={createElement:()=>createCanvas(1,1)};
const {draw,D}=new Function('createCanvas','document',m+';return {draw,D:DUR}')(createCanvas,doc);
const ts=[];for(let t=0;t<D;t+=1/30){const a=process.hrtime.bigint();draw(t);ts.push([t,Number(process.hrtime.bigint()-a)/1e6])}
const v=ts.map(x=>x[1]).sort((a,b)=>a-b),med=v[v.length>>1],p95=v[Math.floor(v.length*.95)];
const bins={};for(const [t,ms] of ts){const k=Math.floor(t/10)*10;(bins[k]=bins[k]||[]).push(ms)}
console.log(`frames ${ts.length}  median ${med.toFixed(0)}ms  p95 ${p95.toFixed(0)}ms  max ${v[v.length-1].toFixed(0)}ms`);
console.log(Object.entries(bins).map(([k,a])=>`${k}-${+k+10}s ${(a.reduce((x,y)=>x+y)/a.length).toFixed(0)}ms`).join(' | '));
console.log('slowest:',ts.slice().sort((a,b)=>b[1]-a[1]).slice(0,4).map(x=>x[0].toFixed(1)+'s').join(' '));
console.log(med>90?'FAIL: too heavy - cut shapes/layers in the slow scenes':med>60?'WARN: heavy - lighten the slowest scenes':'OK');
