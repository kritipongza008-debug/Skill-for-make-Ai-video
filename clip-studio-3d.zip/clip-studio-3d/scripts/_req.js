// Resolve npm packages from ~/.svs (see setup.sh) or the current dir.
const path=require('path'),os=require('os');
module.exports=function req(name){
  const paths=[process.env.SVS_NODE_MODULES&&path.dirname(process.env.SVS_NODE_MODULES),path.join(os.homedir(),'.svs'),process.cwd(),'/home/claude'].filter(Boolean);
  try{return require(require.resolve(name,{paths}))}catch(e){console.error('Missing npm package "'+name+'". Run: bash scripts/setup.sh');process.exit(2)}
};
