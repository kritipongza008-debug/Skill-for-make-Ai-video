#!/usr/bin/env python3
"""Tighten pauses in the voice-over and align script 'cards' (caption phrases) to speech.
Usage: tighten_align.py <project_dir>
Reads : voice.mp3, cards.json, config.json (optional: gap_long, gap_short)
Writes: voice_t.wav, voice_t.mp3, timeline.json  {dur, seg, cards[{text,t0,t1}], stats}
Alignment = dynamic programming over candidate boundaries (segment starts + a 0.3 s grid inside
speech). It matches each card's character weight to its speech duration and prefers boundaries
that sit on real pauses. It is an ESTIMATE: no speech recognition is used (see references/pitfalls.md)."""
import sys,os,json,re,subprocess
sys.path.insert(0,os.path.dirname(__file__))
from analyze_audio import analyze,sh
P=sys.argv[1].rstrip('/');os.chdir(P)
cfg=json.load(open('config.json')) if os.path.exists('config.json') else {}
GL,GS=cfg.get('gap_long',.24),cfg.get('gap_short',.13)
a=analyze('voice.mp3');dur=a['duration'];segs=a['segments'];N=len(segs)
parts=[];new=[];cum=0.0
for i,(s,e) in enumerate(segs):
    prev=segs[i-1][1] if i else 0;nxt=segs[i+1][0] if i<N-1 else dur
    ps=max(0,s-.04) if i==0 else max(prev+(s-prev)/2,s-.04);pe=min(dur,e+.06) if i==N-1 else min(e+.06,e+(nxt-e)/2)
    parts.append(f'[0:a]atrim={ps:.3f}:{pe:.3f},asetpts=PTS-STARTPTS,aformat=sample_rates=44100:channel_layouts=mono[p{i}]')
    new.append([cum+(s-ps),cum+(s-ps)+(e-s)]);cum+=pe-ps
    if i<N-1:
        gap=nxt-e;g=GL if gap>=.5 else min(GS,gap);parts.append(f'anullsrc=r=44100:cl=mono,atrim=0:{g},asetpts=PTS-STARTPTS[g{i}]');cum+=g
order=''.join(f'[p{i}]'+(f'[g{i}]' if i<N-1 else '') for i in range(N))
open('fc.txt','w').write(';'.join(parts)+f';{order}concat=n={2*N-1}:v=0:a=1[o]')
r=sh('ffmpeg -y -loglevel error -i voice.mp3 -filter_complex_script fc.txt -map "[o]" voice_t.wav')
if r.returncode:print(r.stderr);sys.exit(1)
sh('ffmpeg -y -loglevel error -i voice_t.wav -b:a 128k voice_t.mp3')
nd=float(sh('ffprobe -v error -show_entries format=duration -of csv=p=0 voice_t.wav').stdout)
cards=json.load(open('cards.json'));K=len(cards)
def wt(x):return len(x.replace('\n','').replace(' ',''))
W=[wt(c) for c in cards];sp=sum(e-s for s,e in new);rate=sum(W)/sp
cs=[0.0]
for s,e in new:cs.append(cs[-1]+e-s)
def axis(tm):
    for i,(s,e) in enumerate(new):
        if tm<=s:return cs[i]
        if tm<=e:return cs[i]+tm-s
    return cs[-1]
gaps=[0]+[new[i][0]-new[i-1][1] for i in range(1,N)]
cand=[]
for i,(s,e) in enumerate(new):
    cand.append((s,-min(gaps[i],.4)*1.2));x=s+.3
    while x<e-.3:cand.append((x,.9));x+=.3
cand.append((new[-1][1]+.05,0.0));cand.sort();M=len(cand);ax=[axis(c[0]) for c in cand]
INF=1e18;f=[[INF]*M for _ in range(K+1)];bk=[[0]*M for _ in range(K+1)]
for j in range(M):
    if abs(cand[j][0]-new[0][0])<1e-6:f[0][j]=0
for k in range(1,K+1):
    for j in range(1,M):
        for i in range(j):
            if f[k-1][i]>=INF:continue
            d=ax[j]-ax[i]
            if d<.35:continue
            c=f[k-1][i]+(d-W[k-1]/rate)**2+(cand[j][1] if k<K else 0)
            if c<f[k][j]:f[k][j]=c;bk[k][j]=i
if f[K][M-1]>=INF:print('alignment failed: too many cards for this audio. Merge cards or shorten K.');sys.exit(1)
j=M-1;ch=[j]
for k in range(K,0,-1):j=bk[k][j];ch.append(j)
ch.reverse();out=[]
for k in range(K):
    t0=cand[ch[k]][0];b=cand[ch[k+1]][0]
    e=max([x[1] for x in new if x[1]<=b+1e-6 and x[1]>t0]+[b-.05])
    out.append({'text':cards[k],'t0':round(t0,3),'t1':round(min(e+.06,b),3)})
st={'pause_share_after':round(max(0,(nd-sp)/nd),3),'orig_dur':a['duration'],'new_dur':round(nd,3),'saved':round(a['duration']-nd,2),'segments':N,'cards':K,'rate_chars_per_s':round(rate,1),'pause_share_before':a['pause_share']}
json.dump({'dur':round(nd,3),'seg':[[round(x,3),round(y,3)] for x,y in new],'cards':out,'stats':st},open('timeline.json','w'),ensure_ascii=False)
print(json.dumps(st,ensure_ascii=False))
for k,c in enumerate(out):print(k,c['t0'],round(c['t1']-c['t0'],2),c['text'].replace('\n',' '))
